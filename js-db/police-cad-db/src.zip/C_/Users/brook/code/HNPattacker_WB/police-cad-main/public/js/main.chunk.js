(this["webpackJsonppolice-cad-react"] =
  this["webpackJsonppolice-cad-react"] || []).push([
  ["main"],
  {
    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/AboutUs/less/antMotionStyle.less":
      /*!**************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/AboutUs/less/antMotionStyle.less ***!
    \**************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          'body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content6-wrapper {\n  min-height: 720px;\n}\n.content6-wrapper .content6 {\n  height: 100%;\n  display: flex;\n  align-items: center;\n}\n.content6-wrapper .content6-text {\n  min-height: 424px;\n}\n.content6-wrapper .content6-text > *.queue-anim-leaving {\n  position: relative !important;\n}\n.content6-wrapper .content6-text .title-h1 {\n  position: relative;\n  margin: 0 0 16px;\n  text-align: left;\n  font-size: 2em;\n}\n.content6-wrapper .content6-text .title-content {\n  position: relative;\n  margin-bottom: 64px;\n  text-align: left;\n}\n.content6-wrapper .content6-text ul {\n  position: relative;\n  display: inline-block;\n}\n.content6-wrapper .content6-text ul li {\n  margin-bottom: 24px;\n}\n.content6-wrapper .content6-text ul li .content6-icon {\n  display: inline-block;\n  width: 30px;\n  height: 30px;\n  position: absolute;\n}\n.content6-wrapper .content6-text ul li .content6-title,\n.content6-wrapper .content6-text ul li .content6-content {\n  margin-left: 45px;\n}\n.content6-wrapper .content6-text ul li .content6-title {\n  font-size: 14px;\n  margin-bottom: 10px;\n}\n@media screen and (max-width: 767px) {\n  .content6-wrapper {\n    height: 860px;\n    overflow: hidden;\n  }\n  .content6-wrapper .content6 {\n    display: block;\n  }\n  .content6-wrapper .content6-img,\n  .content6-wrapper .content6-text {\n    display: block;\n    width: 100%;\n  }\n  .content6-wrapper .content6-text > h1,\n  .content6-wrapper .content6-text > p {\n    text-align: center;\n  }\n  .content6-wrapper .content6-text > h1 {\n    margin: 56px auto 16px;\n  }\n  .content6-wrapper .content6-text p {\n    margin-bottom: 32px;\n  }\n  .content6-wrapper .content6-img {\n    margin-top: 20px;\n  }\n}\n.content13-wrapper {\n  min-height: 380px;\n  background: url("https://gw.alipayobjects.com/zos/rmsportal/ZsWYzLOItgeaWDSsXdZd.svg") no-repeat bottom;\n  background-size: cover;\n  background-size: 100%;\n  margin: 0 auto;\n  overflow: hidden;\n  padding: 96px 0;\n}\n.content13-wrapper.home-page-wrapper .title-wrapper {\n  margin-bottom: 32px;\n}\n.content13-wrapper .title-content {\n  line-height: 32px;\n}\n@media screen and (max-width: 767px) {\n  .content13-wrapper {\n    padding-bottom: 0;\n  }\n}\n.content11-wrapper {\n  height: 480px;\n  background: url("https://gw.alipayobjects.com/zos/rmsportal/ZsWYzLOItgeaWDSsXdZd.svg") no-repeat bottom;\n  background-size: cover;\n  background-size: 100%;\n  margin: 0 auto;\n  overflow: hidden;\n  padding-top: 96px;\n}\n.content11-wrapper.home-page-wrapper .title-wrapper {\n  margin-bottom: 32px;\n}\n.content11-wrapper .button {\n  box-shadow: 0 8px 16px #0554b7;\n  background: linear-gradient(to right, #05cbff, #1e5aff) !important;\n  height: 42px;\n  line-height: 42px;\n  font-size: 14px;\n  border: 0;\n  border-radius: 21px;\n  color: #fff;\n  width: 128px;\n  padding: 0 15px;\n  display: inline-block;\n  transition: transform 0.3s, box-shadow 0.3s;\n}\n.content11-wrapper .button:hover {\n  transform: translateY(-4px);\n  box-shadow: 0 12px 20px #0554b7;\n}\n.content11-wrapper .button:active {\n  transform: translateY(4px);\n  box-shadow: 0 4px 8px #0554b7;\n}\n.content11-wrapper .title-content {\n  line-height: 32px;\n}\n@media screen and (max-width: 767px) {\n  .content11-wrapper {\n    padding-bottom: 0;\n  }\n}\n#Feature4_0 .ant-row > .lj31crcg4tp-editor_css {\n  max-width: 50%;\n}\n#Content13_0.lj31q4ow5ie-editor_css {\n  background-clip: ;\n  background-image: url();\n}\n#Content13_1.lj31y39tr4-editor_css {\n  background-image: url();\n}\n#Content13_2.lj31zea4qqu-editor_css {\n  background-image: url();\n}\n',
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/ContactUs/less/antMotionStyle.less":
      /*!****************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/ContactUs/less/antMotionStyle.less ***!
    \****************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          'body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content13-wrapper {\n  min-height: 380px;\n  background: url("https://gw.alipayobjects.com/zos/rmsportal/ZsWYzLOItgeaWDSsXdZd.svg") no-repeat bottom;\n  background-size: cover;\n  background-size: 100%;\n  margin: 0 auto;\n  overflow: hidden;\n  padding: 96px 0;\n}\n.content13-wrapper.home-page-wrapper .title-wrapper {\n  margin-bottom: 32px;\n}\n.content13-wrapper .title-content {\n  line-height: 32px;\n}\n@media screen and (max-width: 767px) {\n  .content13-wrapper {\n    padding-bottom: 0;\n  }\n}\n.content11-wrapper {\n  height: 480px;\n  background: url("https://gw.alipayobjects.com/zos/rmsportal/ZsWYzLOItgeaWDSsXdZd.svg") no-repeat bottom;\n  background-size: cover;\n  background-size: 100%;\n  margin: 0 auto;\n  overflow: hidden;\n  padding-top: 96px;\n}\n.content11-wrapper.home-page-wrapper .title-wrapper {\n  margin-bottom: 32px;\n}\n.content11-wrapper .button {\n  box-shadow: 0 8px 16px #0554b7;\n  background: linear-gradient(to right, #05cbff, #1e5aff) !important;\n  height: 42px;\n  line-height: 42px;\n  font-size: 14px;\n  border: 0;\n  border-radius: 21px;\n  color: #fff;\n  width: 128px;\n  padding: 0 15px;\n  display: inline-block;\n  transition: transform 0.3s, box-shadow 0.3s;\n}\n.content11-wrapper .button:hover {\n  transform: translateY(-4px);\n  box-shadow: 0 12px 20px #0554b7;\n}\n.content11-wrapper .button:active {\n  transform: translateY(4px);\n  box-shadow: 0 4px 8px #0554b7;\n}\n.content11-wrapper .title-content {\n  line-height: 32px;\n}\n@media screen and (max-width: 767px) {\n  .content11-wrapper {\n    padding-bottom: 0;\n  }\n}\n#Content13_0.lj33686irk-editor_css {\n  min-height: 250px;\n  background-image: url(\'\');\n}\n#Content11_0.lj3383x3tjr-editor_css {\n  background-image: url();\n}\n#Content11_1.lj33d6mkz09-editor_css {\n  background-image: url();\n}\n',
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Faq/less/antMotionStyle.less":
      /*!**********************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/Faq/less/antMotionStyle.less ***!
    \**********************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          "body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content6-wrapper {\n  min-height: 720px;\n}\n.content6-wrapper .content6 {\n  height: 100%;\n  display: flex;\n  align-items: center;\n}\n.content6-wrapper .content6-text {\n  min-height: 424px;\n}\n.content6-wrapper .content6-text > *.queue-anim-leaving {\n  position: relative !important;\n}\n.content6-wrapper .content6-text .title-h1 {\n  position: relative;\n  margin: 0 0 16px;\n  text-align: left;\n  font-size: 2em;\n}\n.content6-wrapper .content6-text .title-content {\n  position: relative;\n  margin-bottom: 64px;\n  text-align: left;\n}\n.content6-wrapper .content6-text ul {\n  position: relative;\n  display: inline-block;\n}\n.content6-wrapper .content6-text ul li {\n  margin-bottom: 24px;\n}\n.content6-wrapper .content6-text ul li .content6-icon {\n  display: inline-block;\n  width: 30px;\n  height: 30px;\n  position: absolute;\n}\n.content6-wrapper .content6-text ul li .content6-title,\n.content6-wrapper .content6-text ul li .content6-content {\n  margin-left: 45px;\n}\n.content6-wrapper .content6-text ul li .content6-title {\n  font-size: 14px;\n  margin-bottom: 10px;\n}\n@media screen and (max-width: 767px) {\n  .content6-wrapper {\n    height: 860px;\n    overflow: hidden;\n  }\n  .content6-wrapper .content6 {\n    display: block;\n  }\n  .content6-wrapper .content6-img,\n  .content6-wrapper .content6-text {\n    display: block;\n    width: 100%;\n  }\n  .content6-wrapper .content6-text > h1,\n  .content6-wrapper .content6-text > p {\n    text-align: center;\n  }\n  .content6-wrapper .content6-text > h1 {\n    margin: 56px auto 16px;\n  }\n  .content6-wrapper .content6-text p {\n    margin-bottom: 32px;\n  }\n  .content6-wrapper .content6-img {\n    margin-top: 20px;\n  }\n}\n",
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Home/less/antMotionStyle.less":
      /*!***********************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/Home/less/antMotionStyle.less ***!
    \***********************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          'body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.header0 {\n  background: #001529;\n  width: 100%;\n  z-index: 1;\n  box-shadow: 0 5px 8px rgba(0, 0, 0, 0.15);\n  position: relative;\n  top: 0;\n}\n.header0 .home-page {\n  padding: 0 24px;\n}\n.header0-logo {\n  display: inline-block;\n  position: relative;\n  width: 150px;\n  line-height: 64px;\n}\n.header0-logo img {\n  vertical-align: middle;\n  display: inline-block;\n}\n.header0-logo a {\n  display: block;\n}\n.header0-menu {\n  float: right;\n}\n.header0-menu .ant-menu {\n  line-height: 62px;\n  height: 64px;\n}\n.header0-menu .ant-menu a {\n  display: block;\n}\n.header0-item-block {\n  padding: 0 8px;\n}\n.header0-item-block > * {\n  display: inline-block;\n}\n.header0-item .ant-menu-sub .ant-menu-item,\n.header0-item-child .ant-menu-sub .ant-menu-item,\n.header0-menu .ant-menu-sub .ant-menu-item,\n.header0-item .ant-menu-inline .ant-menu-item,\n.header0-item-child .ant-menu-inline .ant-menu-item,\n.header0-menu .ant-menu-inline .ant-menu-item {\n  height: auto;\n  line-height: 1.5;\n}\n.header0-item .item-sub-item,\n.header0-item-child .item-sub-item,\n.header0-menu .item-sub-item {\n  display: block;\n  padding: 8px 24px;\n}\n.header0-item .item-image,\n.header0-item-child .item-image,\n.header0-menu .item-image {\n  float: left;\n  margin-right: 16px;\n  margin-top: 4px;\n  position: relative;\n  z-index: 1;\n}\n.header0-item .item-title,\n.header0-item-child .item-title,\n.header0-menu .item-title {\n  font-size: 14px;\n  color: #fff;\n  margin-left: 46px;\n}\n.header0-item .item-content,\n.header0-item-child .item-content,\n.header0-menu .item-content {\n  font-size: 12px;\n  color: rgba(255, 255, 255, 0.75);\n  margin-left: 46px;\n}\n@media screen and (max-width: 767px) {\n  .header0-logo {\n    z-index: 101;\n  }\n  .header0.home-page-wrapper .home-page {\n    padding: 0 24px;\n  }\n  .header0-menu {\n    height: auto;\n    float: inherit;\n    position: relative;\n    left: -24px;\n    width: calc(100% + 48px);\n    opacity: 0;\n    transition: opacity 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  }\n  .header0-menu li {\n    padding: 0 24px;\n  }\n  .header0-menu li.ant-menu-submenu {\n    padding: 0;\n  }\n  .header0-menu .item-sub-item {\n    padding: 8px 0;\n  }\n  .header0-mobile-menu {\n    width: 16px;\n    height: 14px;\n    cursor: pointer;\n    position: absolute;\n    top: 24px;\n    right: 24px;\n    z-index: 100;\n  }\n  .header0-mobile-menu em {\n    display: block;\n    width: 100%;\n    height: 2px;\n    background: #fff;\n    margin-top: 4px;\n    transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), opacity 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  }\n  .header0-mobile-menu :first-child {\n    margin-top: 0;\n  }\n  .header0 .ant-menu {\n    height: auto;\n    overflow: hidden;\n  }\n  .header0 .ant-menu .ant-menu-item-selected {\n    border: none;\n  }\n  .header0 .open {\n    height: auto;\n  }\n  .header0 .open .header0-mobile-menu em:nth-child(1) {\n    transform: translateY(6px) rotate(45deg);\n  }\n  .header0 .open .header0-mobile-menu em:nth-child(2) {\n    opacity: 0;\n  }\n  .header0 .open .header0-mobile-menu em:nth-child(3) {\n    transform: translateY(-6px) rotate(-45deg);\n  }\n  .header0 .open > .header0-menu {\n    opacity: 1;\n    pointer-events: auto;\n  }\n  .header0-item-block {\n    height: 40px;\n    line-height: 40px;\n  }\n}\n.banner0 {\n  width: 100%;\n  height: 100vh;\n  position: relative;\n  text-align: center;\n  border-color: #666;\n  background-image: url("https://zos.alipayobjects.com/rmsportal/gGlUMYGEIvjDOOw.jpg");\n  background-size: cover;\n  background-attachment: fixed;\n  background-position: center;\n}\n.banner0 .banner0-text-wrapper {\n  display: inline-block;\n  position: absolute;\n  top: 20%;\n  margin: auto;\n  left: 0;\n  right: 0;\n  font-size: 14px;\n  color: #fff;\n  width: 550px;\n}\n.banner0 .banner0-text-wrapper > .queue-anim-leaving {\n  position: relative !important;\n}\n.banner0 .banner0-title {\n  width: 350px;\n  left: 30px;\n  min-height: 60px;\n  margin: auto;\n  display: inline-block;\n  font-size: 40px;\n  position: relative;\n}\n.banner0 .banner0-content {\n  margin-bottom: 20px;\n  word-wrap: break-word;\n  min-height: 24px;\n}\n.banner0 .banner0-button {\n  border: 1px solid #fff;\n  color: #fff;\n  background: transparent;\n  box-shadow: 0 0 0 transparent;\n  font-size: 16px;\n  height: 40px;\n  transition: background 0.45s cubic-bezier(0.215, 0.61, 0.355, 1), box-shadow 0.45s cubic-bezier(0.215, 0.61, 0.355, 1);\n}\n.banner0 .banner0-button:hover {\n  color: #fff;\n  border-color: #fff;\n  background: rgba(255, 255, 255, 0.1);\n  box-shadow: 0 0 10px rgba(50, 250, 255, 0.75);\n}\n.banner0 .banner0-button:focus {\n  color: #fff;\n  border-color: #fff;\n}\n.banner0 .banner0-button.queue-anim-leaving {\n  width: auto;\n}\n.banner0 .banner0-icon {\n  bottom: 20px;\n  font-size: 24px;\n  position: absolute;\n  left: 50%;\n  margin-left: -12px;\n  color: #fff;\n}\n@media screen and (max-width: 767px) {\n  .banner0 {\n    background-attachment: inherit;\n  }\n  .banner0 .banner0-text-wrapper {\n    width: 90%;\n  }\n  .banner0 .banner0-title {\n    width: 90%;\n    left: 0;\n  }\n}\n.content0-wrapper {\n  min-height: 446px;\n  overflow: hidden;\n}\n.content0-wrapper .content0 {\n  height: 100%;\n  padding: 64px 24px;\n}\n.content0-wrapper .content0 > .title-wrapper {\n  margin: 0 auto 48px;\n}\n.content0-wrapper .content0-block {\n  padding: 0 4%;\n  display: inline-block;\n  text-align: center;\n  min-height: 200px;\n  margin-bottom: 24px;\n}\n.content0-wrapper .content0-block img {\n  width: 100%;\n}\n.content0-wrapper .content0-block-wrapper {\n  position: relative;\n  height: 100%;\n  top: 25%;\n  padding: 20px 0;\n}\n.content0-wrapper .content0-block.queue-anim-leaving {\n  position: relative !important;\n}\n.content0-wrapper .content0-block-icon {\n  width: 100px;\n  height: 100px;\n  margin: auto;\n}\n.content0-wrapper .content0-block-title {\n  line-height: 32px;\n  margin: 10px auto;\n  font-size: 24px;\n}\n@media screen and (max-width: 767px) {\n  .content0-wrapper {\n    min-height: 880px;\n  }\n}\n.feature6-wrapper {\n  min-height: 360px;\n  margin: 0 auto;\n  overflow: hidden;\n}\n.feature6-wrapper.home-page-wrapper .home-page {\n  padding: 64px 24px;\n}\n.feature6-title {\n  display: inline-block;\n}\n.feature6-title-wrapper {\n  text-align: center;\n  margin-bottom: 48px;\n}\n.feature6-title-text {\n  display: inline-block;\n  margin: 0 72px;\n  font-size: 24px;\n  color: rgba(0, 0, 0, 0.85);\n  transition: color 0.45s cubic-bezier(0.645, 0.045, 0.355, 1);\n  cursor: pointer;\n}\n.feature6-title-text.active {\n  color: #1DA57A;\n}\n.feature6-title-bar {\n  height: 6px;\n  background: #1DA57A;\n  width: 20%;\n  margin: auto;\n  display: block;\n}\n.feature6-title-bar-wrapper {\n  position: relative;\n  margin-top: 8px;\n  transition: left 0.45s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.feature6-number,\n.feature6-text {\n  text-align: center;\n}\n.feature6-number {\n  font-size: 48px;\n  color: #1DA57A;\n  font-weight: 600;\n}\n.feature6-number-wrapper {\n  text-align: center;\n}\n.feature6-text {\n  font-size: 20px;\n}\n.feature6-unit {\n  font-size: 16px;\n  color: #1DA57A;\n}\n.feature6 .ant-carousel .slick-dots-bottom {\n  bottom: -24px;\n}\n.feature6 .ant-carousel .slick-dots li button {\n  background: rgba(29, 165, 122, 0.3);\n}\n.feature6 .ant-carousel .slick-dots li.slick-active button {\n  background: #1DA57A;\n}\n@media screen and (max-width: 767px) {\n  .feature6-wrapper {\n    padding-bottom: 0;\n    min-height: 580px;\n  }\n  .feature6-wrapper.home-page-wrapper .home-page {\n    padding: 56px 24px 64px;\n  }\n  .feature6-title-text {\n    margin: 0 14px;\n  }\n  .feature6-title-bar {\n    width: 40%;\n  }\n  .feature6-number-wrapper {\n    margin-bottom: 16px;\n  }\n}\n.content3-wrapper {\n  min-height: 764px;\n}\n.content3-wrapper .content3 {\n  height: 100%;\n  overflow: hidden;\n}\n.content3-wrapper .content3 .title-content {\n  text-align: center;\n}\n.content3-wrapper .content3-block-wrapper {\n  position: relative;\n}\n.content3-wrapper .content3-block-wrapper .content3-block {\n  display: inline-block;\n  padding: 48px 24px;\n  vertical-align: top;\n}\n.content3-wrapper .content3-block-wrapper .content3-block .content3-icon {\n  display: inline-block;\n  width: 15%;\n  vertical-align: top;\n}\n.content3-wrapper .content3-block-wrapper .content3-block .content3-text {\n  width: 85%;\n  display: inline-block;\n  padding-left: 8%;\n}\n.content3-wrapper .content3-block-wrapper .content3-block.clear-both {\n  clear: both;\n}\n@media screen and (max-width: 767px) {\n  .content3-wrapper {\n    min-height: 1080px;\n  }\n  .content3-wrapper .content3-block-wrapper {\n    margin: 20px auto;\n    height: auto;\n  }\n  .content3-wrapper .content3-block-wrapper .content3-block .content3-title {\n    font-size: 20px;\n  }\n  .content3-wrapper .content3-block-wrapper .content3-block.queue-anim-leaving {\n    position: relative !important;\n  }\n}\n.footer1-wrapper {\n  background: #001529;\n  overflow: hidden;\n  position: relative;\n  min-height: 360px;\n  color: #999;\n}\n.footer1-wrapper .footer1 .home-page {\n  padding: 64px 24px 80px;\n}\n.footer1-wrapper .block {\n  padding: 0 32px;\n}\n.footer1-wrapper .block .logo {\n  max-width: 180px;\n}\n.footer1-wrapper .block .slogan {\n  font-size: 12px;\n  margin-top: -20px;\n}\n.footer1-wrapper .block > h2 {\n  margin-bottom: 24px;\n  color: #ccc;\n}\n.footer1-wrapper .block a {\n  color: #999;\n  margin-bottom: 12px;\n  float: left;\n  clear: both;\n}\n.footer1-wrapper .block a:hover {\n  color: #1DA57A;\n}\n.footer1-wrapper .copyright-wrapper {\n  width: 100%;\n  border-top: 1px solid rgba(233, 233, 233, 0.1);\n}\n.footer1-wrapper .copyright-wrapper .home-page {\n  padding: 0 24px;\n  overflow: hidden;\n}\n.footer1-wrapper .copyright-wrapper .copyright {\n  height: 80px;\n  text-align: center;\n  line-height: 80px;\n}\n@media screen and (max-width: 767px) {\n  .footer1 {\n    min-height: 550px;\n  }\n  .footer1-wrapper .footer1 .home-page {\n    padding: 64px 24px 32px;\n  }\n  .footer1 .logo {\n    margin: 0 auto 24px;\n  }\n  .footer1 .block {\n    text-align: center;\n    margin-bottom: 32px;\n    padding: 0;\n  }\n  .footer1 > ul {\n    width: 90%;\n    margin: 20px auto 0;\n    padding: 10px 0;\n  }\n  .footer1 > ul > li {\n    width: 100%;\n  }\n  .footer1 > ul > li h2 {\n    margin-bottom: 10px;\n  }\n  .footer1 > ul > li li {\n    display: inline-block;\n    margin-right: 10px;\n  }\n  .footer1 .copyright-wrapper .home-page {\n    padding: 0;\n  }\n  .footer1 .copyright-wrapper .home-page .copyright {\n    font-size: 12px;\n  }\n  .footer1 .copyright span {\n    width: 90%;\n  }\n}\n#Banner0_1 .lig76kd43qs-editor_css {\n  justify-content: space-around;\n}\n#Banner0_1 .banner0-text-wrapper > .lig76enk3kh-editor_css {\n  display: flex;\n  left: 0px;\n}\n#Banner0_1.likygdl71t-editor_css {\n  top: 0;\n}\n#Banner0_1 .banner0-text-wrapper > .ligdeo3ow6-editor_css {\n  top: 0px;\n}\n#Banner0_1 .banner0-text-wrapper > .lig7ognf8u-editor_css {\n  color: #fbfbfb;\n  width: 100%;\n  position: relative;\n}\n',
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Login/less/antMotionStyle.less":
      /*!************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/Login/less/antMotionStyle.less ***!
    \************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          "body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content5-wrapper {\n  background-color: #fafafa;\n  min-height: 720px;\n}\n.content5-wrapper .content5 > p {\n  text-align: center;\n}\n.content5-wrapper .content5-img-wrapper {\n  margin: 0 auto;\n  left: 0;\n  right: 0;\n}\n.content5-wrapper .content5-img-wrapper .block {\n  margin-bottom: 24px;\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content {\n  display: block;\n  background: #fff;\n  border-radius: 4px;\n  padding: 10px;\n  text-align: center;\n  position: relative;\n  overflow: hidden;\n  border-radius: 6px;\n  border: 1px solid #e9e9e9;\n  transform: translateY(0);\n  transition: transform 0.3s cubic-bezier(0.215, 0.61, 0.355, 1), box-shadow 0.3s cubic-bezier(0.215, 0.61, 0.355, 1);\n  border: none;\n  color: rgba(0, 0, 0, 0.85);\n  transition: box-shadow 0.3s cubic-bezier(0.215, 0.61, 0.355, 1), transform 0.3s cubic-bezier(0.215, 0.61, 0.355, 1);\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content:hover {\n  box-shadow: 0 5px 8px rgba(0, 0, 0, 0.15);\n  transform: translateY(-5px);\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content > span {\n  width: 100%;\n  height: 160px;\n  display: block;\n  background: #e9e9e9;\n  padding: 5%;\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content p {\n  width: 100%;\n  line-height: 30px;\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content:hover p {\n  bottom: 0;\n}\n@media screen and (max-width: 767px) {\n  .content5-wrapper {\n    height: 2000px;\n    overflow: hidden;\n  }\n  .content5-wrapper .content5 ul li {\n    display: block;\n    width: 100%;\n    padding: 2%;\n  }\n  .content5-wrapper .content5 ul li span {\n    height: 168px;\n  }\n  .content5-wrapper .content5 ul li p {\n    position: relative;\n    bottom: 0;\n  }\n}\n",
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PageNotFound/less/antMotionStyle.less":
      /*!*******************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/PageNotFound/less/antMotionStyle.less ***!
    \*******************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          'body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.banner1 {\n  width: 100%;\n  height: 100vh;\n  position: relative;\n  border-color: #666;\n  background: #fff;\n}\n.banner1-wrapper,\n.banner1 .banner-anim {\n  height: 100%;\n}\n.banner1 .queue-anim-leaving {\n  position: relative !important;\n}\n.banner1 .banner-user-elem {\n  height: 100%;\n  color: #fff;\n  position: relative;\n  overflow: hidden;\n}\n.banner1 .bg0 {\n  background: url("https://zos.alipayobjects.com/rmsportal/hzPBTkqtFpLlWCi.jpg") center;\n}\n.banner1 .bg1 {\n  background: url("https://zos.alipayobjects.com/rmsportal/xHxWkcvaIcuAdQl.jpg") center;\n}\n.banner1 .bg {\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  overflow: hidden;\n  background-size: cover;\n}\n.banner1 .banner-user-elem .banner-user-title {\n  font-size: 22px;\n  top: 40%;\n}\n.banner1 .banner-user-elem .banner-user-text {\n  top: 40%;\n}\n.banner1 .banner1-text-wrapper {\n  display: block;\n  position: relative;\n  top: 20%;\n  left: 0;\n  right: 0;\n  margin: auto;\n  font-size: 14px;\n  color: #fff;\n  width: 550px;\n  text-align: center;\n}\n.banner1 .banner1-title {\n  width: 350px;\n  left: 30px;\n  margin: auto;\n  display: inline-block;\n  font-size: 40px;\n  position: relative;\n}\n.banner1 .banner1-content {\n  margin-bottom: 20px;\n  word-wrap: break-word;\n}\n.banner1 .banner1-button {\n  border: 1px solid #fff;\n  color: #fff;\n  background: transparent;\n  box-shadow: 0 0 0 transparent;\n  transition: background 0.45s cubic-bezier(0.215, 0.61, 0.355, 1), box-shadow 0.45s cubic-bezier(0.215, 0.61, 0.355, 1);\n  line-height: 36px;\n  font-size: 16px;\n  height: 36px;\n}\n.banner1 .banner1-button span {\n  text-shadow: 0 0 0 rgba(0, 0, 0, 0);\n  transition: text-shadow 0.45s cubic-bezier(0.215, 0.61, 0.355, 1);\n}\n.banner1 .banner1-button:hover {\n  color: #fff;\n  border-color: #fff;\n  background: rgba(255, 255, 255, 0.1);\n  box-shadow: 0 0 10px rgba(50, 250, 255, 0.75);\n}\n.banner1 .banner1-button:hover span {\n  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.35);\n}\n.banner1 .banner1-button.queue-anim-leaving {\n  width: auto;\n}\n.banner1 .banner1-icon {\n  bottom: 20px;\n  font-size: 24px;\n  position: absolute;\n  z-index: 10;\n  left: 50%;\n  margin-left: -12px;\n  color: #fff;\n}\n.banner-anim-thumb-default span {\n  width: 10px;\n  height: 10px;\n  border-radius: 10px;\n  background: rgba(255, 255, 255, 0.5);\n}\n@media screen and (max-width: 767px) {\n  .banner1 .banner1-text-wrapper {\n    width: 90%;\n  }\n  .banner1 .banner1-text-wrapper .banner1-title {\n    width: 90%;\n    left: 0;\n  }\n  .banner1 .bg {\n    background-attachment: inherit;\n  }\n}\n#Banner1_0 .banner-anim-elem > .banner1-text-wrapper > .lj7ljmx7pgb-editor_css {\n  display: flex;\n  justify-content: center;\n  font-size: 80px;\n}\n#Banner1_0 .banner-anim-elem > .banner1-text-wrapper > .lj7lrdoyht-editor_css {\n  font-size: 20px;\n}\n',
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PrivacyPolicy/less/antMotionStyle.less":
      /*!********************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/PrivacyPolicy/less/antMotionStyle.less ***!
    \********************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          'body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content13-wrapper {\n  min-height: 380px;\n  background: url("https://gw.alipayobjects.com/zos/rmsportal/ZsWYzLOItgeaWDSsXdZd.svg") no-repeat bottom;\n  background-size: cover;\n  background-size: 100%;\n  margin: 0 auto;\n  overflow: hidden;\n  padding: 96px 0;\n}\n.content13-wrapper.home-page-wrapper .title-wrapper {\n  margin-bottom: 32px;\n}\n.content13-wrapper .title-content {\n  line-height: 32px;\n}\n@media screen and (max-width: 767px) {\n  .content13-wrapper {\n    padding-bottom: 0;\n  }\n}\n#Content13_1 .title-wrapper > .lj3ae1qhurf-editor_css {\n  text-align: left;\n  margin: 0 4em;\n}\n#Content13_1.lj3aekvt5qb-editor_css {\n  background-image: url();\n}\n',
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Signup/less/antMotionStyle.less":
      /*!*************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/Signup/less/antMotionStyle.less ***!
    \*************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          "body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content5-wrapper {\n  background-color: #fafafa;\n  min-height: 720px;\n}\n.content5-wrapper .content5 > p {\n  text-align: center;\n}\n.content5-wrapper .content5-img-wrapper {\n  margin: 0 auto;\n  left: 0;\n  right: 0;\n}\n.content5-wrapper .content5-img-wrapper .block {\n  margin-bottom: 24px;\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content {\n  display: block;\n  background: #fff;\n  border-radius: 4px;\n  padding: 10px;\n  text-align: center;\n  position: relative;\n  overflow: hidden;\n  border-radius: 6px;\n  border: 1px solid #e9e9e9;\n  transform: translateY(0);\n  transition: transform 0.3s cubic-bezier(0.215, 0.61, 0.355, 1), box-shadow 0.3s cubic-bezier(0.215, 0.61, 0.355, 1);\n  border: none;\n  color: rgba(0, 0, 0, 0.85);\n  transition: box-shadow 0.3s cubic-bezier(0.215, 0.61, 0.355, 1), transform 0.3s cubic-bezier(0.215, 0.61, 0.355, 1);\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content:hover {\n  box-shadow: 0 5px 8px rgba(0, 0, 0, 0.15);\n  transform: translateY(-5px);\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content > span {\n  width: 100%;\n  height: 160px;\n  display: block;\n  background: #e9e9e9;\n  padding: 5%;\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content p {\n  width: 100%;\n  line-height: 30px;\n}\n.content5-wrapper .content5-img-wrapper .block .content5-block-content:hover p {\n  bottom: 0;\n}\n@media screen and (max-width: 767px) {\n  .content5-wrapper {\n    height: 2000px;\n    overflow: hidden;\n  }\n  .content5-wrapper .content5 ul li {\n    display: block;\n    width: 100%;\n    padding: 2%;\n  }\n  .content5-wrapper .content5 ul li span {\n    height: 168px;\n  }\n  .content5-wrapper .content5 ul li p {\n    position: relative;\n    bottom: 0;\n  }\n}\n#Content5_0 .home-page > .title-wrapper > .lja75phz19k-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .home-page > .title-wrapper > .lja75xnlm9s-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .home-page > .title-wrapper > .lja706c8vys-editor_css {\n  font-size: 16px;\n  color: #fbfbfb;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja787k3ld7-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja78krpxml-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja78p49zx-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja78xkehr-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja79677l68-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja79e9m1m8-editor_css {\n  color: #fbfbfb;\n}\n#Content5_0 .lja74sp6nmt-editor_css {\n  background-image: url('https://zos.alipayobjects.com/rmsportal/gGlUMYGEIvjDOOw.jpg');\n  background-attachment: scroll;\n  background-position: 0% 0%;\n  background-repeat: repeat;\n  background-size: auto;\n  background-clip: border-box;\n  border-color: #00a854;\n}\n#Content5_0 div > .ant-row > .lja7c6wz7vt-editor_css {\n  border-color: #173631;\n}\n#Content5_0 div > .ant-row > .lja7fuhkkt-editor_css {\n  border-width: 1px;\n}\n#Content5_0 .ant-col > .content5-block-content > .lja7hr31iy-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n}\n#Content5_0 .ant-col > .content5-block-content > .lja7iwizeuq-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n}\n#Content5_0 .ant-col > .content5-block-content > .lja7izocmgf-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n}\n#Content5_0 .ant-col > .content5-block-content > .lja7j2ivdgq-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n}\n#Content5_0 .ant-col > .content5-block-content > .lja7j61e72-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n}\n#Content5_0 .ant-col > .content5-block-content > .lja7j8ssy7-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n}\n#Content5_0 .ant-row > .ant-col > .lja78c03dqk-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n  border-top-style: solid;\n  border-right-style: solid;\n  border-bottom-style: solid;\n  border-left-style: solid;\n  border-color: #0f77fe;\n  border-top-width: 3px;\n  border-right-width: 3px;\n  border-bottom-width: 3px;\n  border-left-width: 3px;\n}\n#Content5_0 .ant-row > .ant-col > .lja78sleycj-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n  border-top-style: solid;\n  border-right-style: solid;\n  border-bottom-style: solid;\n  border-left-style: solid;\n  border-color: #0f77fe;\n  border-top-width: 3px;\n  border-right-width: 3px;\n  border-bottom-width: 3px;\n  border-left-width: 3px;\n}\n#Content5_0 .ant-row > .ant-col > .lja790verco-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n  border-top-style: solid;\n  border-right-style: solid;\n  border-bottom-style: solid;\n  border-left-style: solid;\n  border-color: #0f77fe;\n  border-top-width: 3px;\n  border-right-width: 3px;\n  border-bottom-width: 3px;\n  border-left-width: 3px;\n}\n#Content5_0 .ant-row > .ant-col > .lja799kmegi-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n  border-top-style: solid;\n  border-right-style: solid;\n  border-bottom-style: solid;\n  border-left-style: solid;\n  border-color: #0f77fe;\n  border-top-width: 3px;\n  border-right-width: 3px;\n  border-bottom-width: 3px;\n  border-left-width: 3px;\n}\n#Content5_0 .ant-row > .ant-col > .lja79icitt-editor_css {\n  background-color: rgba(0, 0, 0, 0);\n  border-top-style: solid;\n  border-right-style: solid;\n  border-bottom-style: solid;\n  border-left-style: solid;\n  border-color: #0f77fe;\n  border-top-width: 3px;\n  border-right-width: 3px;\n  border-bottom-width: 3px;\n  border-left-width: 3px;\n}\n#Content5_0 .ant-row > .ant-col > .lja76825yz-editor_css {\n  background-clip: padding-box;\n  background-color: rgba(0, 0, 0, 0);\n  border-top-style: solid;\n  border-right-style: solid;\n  border-bottom-style: solid;\n  border-left-style: solid;\n  border-color: #0f77fe;\n  border-top-width: 3px;\n  border-right-width: 3px;\n  border-bottom-width: 3px;\n  border-left-width: 3px;\n}\n#Content5_0.ljab3gqifyl-editor_css {\n  background-clip: padding-box;\n  background-color: #161a1d;\n}\n",
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/TermsAndConditions/less/antMotionStyle.less":
      /*!*************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!./node_modules/postcss-loader/src??postcss!./node_modules/resolve-url-loader??ref--6-oneOf-7-3!./node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./src/TermsAndConditions/less/antMotionStyle.less ***!
    \*************************************************************************************************************************************************************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          "body {\n  word-wrap: break-word;\n}\nbody,\ndiv,\ndl,\ndt,\ndd,\nul,\nol,\nli,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  margin: 0;\n  padding: 0;\n}\n/* .content-wrapper > .tween-one-leaving,\n.queue-anim-leaving {\n  // position: absolute !important;\n  // width: 100%;\n} */\n.video {\n  max-width: 800px;\n}\n#react-content {\n  min-height: 100%;\n}\n.home-page-wrapper p {\n  padding: 0;\n  margin: 0;\n}\n/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n/* 详细页图片或框框的样式;\n*/\n.home-page-wrapper {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.home-page-wrapper .home-page {\n  height: 100%;\n  max-width: 1200px;\n  position: relative;\n  margin: auto;\n  will-change: transform;\n}\n.home-page-wrapper .title-wrapper > h1,\n.home-page-wrapper > h1 {\n  font-size: 32px;\n  color: rgba(0, 0, 0, 0.85);\n  margin-bottom: 16px;\n}\n.home-page-wrapper .title-wrapper {\n  margin: 0 auto 64px;\n  text-align: center;\n}\n.home-page {\n  padding: 128px 24px;\n}\n@media screen and (max-width: 767px) {\n  .home-page-wrapper .home-page {\n    padding: 56px 24px;\n  }\n  .home-page-wrapper .home-page > h1 {\n    font-size: 24px;\n    margin: 0 auto 32px;\n  }\n  .home-page-wrapper .home-page > h1.title-h1 {\n    margin-bottom: 8px;\n  }\n  .home-page-wrapper .home-page > p {\n    margin-bottom: 32px;\n  }\n}\n.content13-wrapper {\n  min-height: 380px;\n  background: url(\"https://gw.alipayobjects.com/zos/rmsportal/ZsWYzLOItgeaWDSsXdZd.svg\") no-repeat bottom;\n  background-size: cover;\n  background-size: 100%;\n  margin: 0 auto;\n  overflow: hidden;\n  padding: 96px 0;\n}\n.content13-wrapper.home-page-wrapper .title-wrapper {\n  margin-bottom: 32px;\n}\n.content13-wrapper .title-content {\n  line-height: 32px;\n}\n@media screen and (max-width: 767px) {\n  .content13-wrapper {\n    padding-bottom: 0;\n  }\n}\n#Content13_2.lj39jud6ngt-editor_css {\n  background-image: url();\n}\n#Content13_2 .title-wrapper > .lj39j5xv1or-editor_css {\n  text-align: left;\n  margin: 0 2em;\n}\n#Content13_3.lj39mclik0g-editor_css {\n  background-image: url();\n}\n#Content13_3 .title-wrapper > .lj39nmh2z7j-editor_css {\n  text-align: left;\n  margin: 0 4em;\n}\n#Content13_3 .title-wrapper > .lj3a3dnbrpn-editor_css {\n  text-align: left;\n  margin: 0 4em;\n}\n#Content13_0.lj33686irk-editor_css {\n  max-height: 200px;\n  min-height: 250px;\n  background-image: url('');\n}\n",
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css":
      /*!**************************************************************************************************************************!*\
    !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/index.css ***!
    \**************************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        // Imports
        var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
          /*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
        );
        exports = ___CSS_LOADER_API_IMPORT___(false);
        // Module
        exports.push([
          module.i,
          "body {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',\n    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',\n    monospace;\n}\n",
          "",
        ]);
        // Exports
        module.exports = exports;

        /***/
      },

    /***/ "./src/AboutUs/Content11.jsx":
      /*!***********************************!*\
    !*** ./src/AboutUs/Content11.jsx ***!
    \***********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(/*! ./utils */ "./src/AboutUs/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/AboutUs/Content11.jsx";

        class Content11 extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3___default.a,
              Object.assign({}, props, dataSource.OverPack, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__["default"],
                Object.assign(
                  {
                    type: "bottom",
                    leaveReverse: true,
                    key: "page",
                    delay: [0, 100],
                  },
                  dataSource.titleWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 16,
                      columnNumber: 9,
                    },
                  }
                ),
                dataSource.titleWrapper.children.map(
                  _utils__WEBPACK_IMPORTED_MODULE_6__["getChildrenToRender"]
                )
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                Object.assign(
                  {
                    key: "button",
                    style: {
                      textAlign: "center",
                    },
                  },
                  dataSource.button,
                  {
                    animation: {
                      y: 30,
                      opacity: 0,
                      type: "from",
                      delay: 300,
                    },
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 25,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                  Object.assign({}, dataSource.button.children.a, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 31,
                      columnNumber: 11,
                    },
                  }),
                  dataSource.button.children.a.children
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content11;

        /***/
      },

    /***/ "./src/AboutUs/Content13.jsx":
      /*!***********************************!*\
    !*** ./src/AboutUs/Content13.jsx ***!
    \***********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./utils */ "./src/AboutUs/utils.js");
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/AboutUs/Content13.jsx";

        class Content13 extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default.a,
              Object.assign({}, props, dataSource.OverPack, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 13,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__["default"],
                Object.assign(
                  {
                    type: "bottom",
                    leaveReverse: true,
                    key: "page",
                    delay: [0, 100],
                  },
                  dataSource.titleWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 14,
                      columnNumber: 9,
                    },
                  }
                ),
                dataSource.titleWrapper.children.map(
                  _utils__WEBPACK_IMPORTED_MODULE_3__["getChildrenToRender"]
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content13;

        /***/
      },

    /***/ "./src/AboutUs/Feature4.jsx":
      /*!**********************************!*\
    !*** ./src/AboutUs/Feature4.jsx ***!
    \**********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(/*! ./utils */ "./src/AboutUs/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/AboutUs/Feature4.jsx";

        class Content7 extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .Component {
          constructor() {
            super(...arguments);
            this.getBlockChildren = (data) =>
              data.map(($item) => {
                const { ...item } = $item;
                const { title, img, content } = item;
                ["title", "img", "content"].forEach((key) => delete item[key]);
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "li",
                  Object.assign(
                    {
                      key: item.name,
                    },
                    item,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 15,
                        columnNumber: 9,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "span",
                    Object.assign({}, img, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 16,
                        columnNumber: 11,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "img",
                      {
                        src: img.children,
                        width: "100%",
                        alt: "img",
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 17,
                          columnNumber: 13,
                        },
                      }
                    )
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "h2",
                    Object.assign({}, title, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 19,
                        columnNumber: 11,
                      },
                    }),
                    title.children
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "div",
                    Object.assign({}, content, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 20,
                        columnNumber: 11,
                      },
                    }),
                    content.children
                  )
                );
              });
          }
          render() {
            const { ...props } = this.props;
            const { dataSource, isMobile } = props;
            delete props.dataSource;
            delete props.isMobile;
            const ulChildren = this.getBlockChildren(dataSource.block.children);
            const queue = isMobile ? "bottom" : "left";
            const imgAnim = isMobile
              ? {
                  y: 30,
                  opacity: 0,
                  delay: 600,
                  type: "from",
                  ease: "easeOutQuad",
                }
              : {
                  x: 30,
                  opacity: 0,
                  type: "from",
                  ease: "easeOutQuad",
                };
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 47,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default.a,
                Object.assign({}, dataSource.OverPack, {
                  component:
                    antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 48,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_queue_anim__WEBPACK_IMPORTED_MODULE_6__["default"],
                  Object.assign(
                    {
                      key: "text",
                      type: queue,
                      leaveReverse: true,
                      ease: ["easeOutQuad", "easeInQuad"],
                    },
                    dataSource.textWrapper,
                    {
                      component:
                        antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 49,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "div",
                    Object.assign(
                      {
                        key: "title",
                      },
                      dataSource.titleWrapper,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 57,
                          columnNumber: 13,
                        },
                      }
                    ),
                    dataSource.titleWrapper.children.map(
                      _utils__WEBPACK_IMPORTED_MODULE_8__["getChildrenToRender"]
                    )
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_queue_anim__WEBPACK_IMPORTED_MODULE_6__["default"],
                    Object.assign(
                      {
                        component: "ul",
                        key: "ul",
                        type: queue,
                        ease: "easeOutQuad",
                      },
                      dataSource.block,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 60,
                          columnNumber: 13,
                        },
                      }
                    ),
                    ulChildren
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                  Object.assign(
                    {
                      key: "img",
                      animation: imgAnim,
                      resetStyle: true,
                    },
                    dataSource.img,
                    {
                      component:
                        antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 70,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "img",
                    {
                      src: dataSource.img.children,
                      width: "100%",
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 77,
                        columnNumber: 13,
                      },
                    }
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content7;

        /***/
      },

    /***/ "./src/AboutUs/Nav0.jsx":
      /*!******************************!*\
    !*** ./src/AboutUs/Nav0.jsx ***!
    \******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/AboutUs/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/AboutUs/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/AboutUs/data.source.js":
      /*!************************************!*\
    !*** ./src/AboutUs/data.source.js ***!
    \************************************/
      /*! exports provided: Nav00DataSource, Feature40DataSource, Content130DataSource, Content131DataSource, Content132DataSource, Content110DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Feature40DataSource",
          function () {
            return Feature40DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content130DataSource",
          function () {
            return Content130DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content131DataSource",
          function () {
            return Content131DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content132DataSource",
          function () {
            return Content132DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content110DataSource",
          function () {
            return Content110DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/AboutUs/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Feature40DataSource = {
          wrapper: {
            className: "home-page-wrapper content6-wrapper",
          },
          OverPack: {
            className: "home-page content6",
          },
          textWrapper: {
            className: "content6-text",
            xs: 24,
            md: 10,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 122,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 123,
                          columnNumber: 13,
                        },
                      },
                      "About Us",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 125,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                className: "title-content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 136,
                          columnNumber: 13,
                        },
                      },
                      "LPC - Lines Police CAD",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 138,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
              },
            ],
          },
          img: {
            children: "https://cdn-icons-png.flaticon.com/512/3109/3109599.png",
            className: "content6-img lj31crcg4tp-editor_css",
            xs: 24,
            md: 14,
          },
          block: {
            children: [
              {
                name: "block0",
                img: {
                  children:
                    "https://zos.alipayobjects.com/rmsportal/NKBELAOuuKbofDD.png",
                  className: "content6-icon",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 163,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 164,
                            columnNumber: 15,
                          },
                        },
                        "Free to use",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 166,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 174,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 175,
                            columnNumber: 15,
                          },
                        },
                        "This is the worlds leading free to use Civilian, Police, EMS, Dispatch management CAD (Computer Aided Dispatch) tool.",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 178,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
              },
              {
                name: "block1",
                img: {
                  className: "content6-icon",
                  children:
                    "https://zos.alipayobjects.com/rmsportal/xMSBjgxBhKfyMWX.png",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 194,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 195,
                            columnNumber: 15,
                          },
                        },
                        "Developed with Users in Mind",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 197,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 205,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 206,
                            columnNumber: 15,
                          },
                        },
                        "Built to help facilitate role-play communities across the globe. Always looking to keep the users at the forefront for new features and use cases.",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 210,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
              },
              {
                name: "block2",
                img: {
                  className: "content6-icon",
                  children:
                    "https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 226,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 227,
                            columnNumber: 15,
                          },
                        },
                        "Web, Mobile & Tablet Friendly",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 229,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 237,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 238,
                            columnNumber: 15,
                          },
                        },
                        "Our service can support however you access the internet. We want to make each experience great. ",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 240,
                              columnNumber: 48,
                            },
                          }
                        )
                      )
                    ),
                },
              },
            ],
          },
        };
        const Content130DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj31q4ow5ie-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 266,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 267,
                          columnNumber: 13,
                        },
                      },
                      "Contributions"
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 275,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 276,
                          columnNumber: 13,
                        },
                      },
                      "There are a few ways you can help contribute, if you are interested",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 279,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 288,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 289,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 290,
                            columnNumber: 15,
                          },
                        },
                        "- Just by using this site and providing feedback is a great way to share that you like what you are using. Thank you!"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 294,
                            columnNumber: 15,
                          },
                        },
                        "- For any coders out there, check out our",
                        " ",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "https://github.com/linesmerrill/police-cad",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 296,
                              columnNumber: 17,
                            },
                          },
                          "GitHub"
                        ),
                        " ",
                        "to help develop and work on the latest features, or even suggest your own."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 306,
                            columnNumber: 15,
                          },
                        },
                        "- Feel free to follow us on Patreon, or join the cause and become on of our Patreon supporters. You can find us here:",
                        " ",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "https://www.patreon.com/linespolicecad",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 309,
                              columnNumber: 17,
                            },
                          },
                          "Lines Police CAD Patreon"
                        )
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 317,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 318,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    )
                  ),
                className: "title-content",
              },
            ],
          },
        };
        const Content131DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj31y39tr4-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 345,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 346,
                          columnNumber: 13,
                        },
                      },
                      "Privacy Policy",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 348,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 357,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 358,
                          columnNumber: 13,
                        },
                      },
                      "Check out our privacy policy:",
                      " ",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "a",
                        {
                          href: "/privacy-policy",
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 360,
                            columnNumber: 15,
                          },
                        },
                        "Privacy Policy"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 361,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
            ],
          },
        };
        const Content132DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj31zea4qqu-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 387,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 388,
                          columnNumber: 13,
                        },
                      },
                      "Terms and Conditions",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 390,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 399,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 400,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 401,
                            columnNumber: 15,
                          },
                        },
                        "Check out our terms and conditions:",
                        " ",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "/terms-and-conditions",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 403,
                              columnNumber: 17,
                            },
                          },
                          "Terms and Conditions"
                        ),
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 404,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    )
                  ),
                className: "title-content",
              },
            ],
          },
        };
        const Content110DataSource = {
          OverPack: {
            className: "home-page-wrapper content11-wrapper",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 431,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 432,
                          columnNumber: 13,
                        },
                      },
                      "Contact Us",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 434,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 443,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 444,
                          columnNumber: 13,
                        },
                      },
                      "We love feedback, check out our contact us page.",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 446,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
            ],
          },
          button: {
            className: "",
            children: {
              a: {
                className: "button",
                href: "/contact-us",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 461,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 462,
                          columnNumber: 13,
                        },
                      },
                      "Contact Us",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 464,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
              },
            },
          },
        };

        /***/
      },

    /***/ "./src/AboutUs/index.jsx":
      /*!*******************************!*\
    !*** ./src/AboutUs/index.jsx ***!
    \*******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/AboutUs/Nav0.jsx");
        /* harmony import */ var _Feature4__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./Feature4 */ "./src/AboutUs/Feature4.jsx");
        /* harmony import */ var _Content13__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./Content13 */ "./src/AboutUs/Content13.jsx");
        /* harmony import */ var _Content11__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(/*! ./Content11 */ "./src/AboutUs/Content11.jsx");
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! ./data.source */ "./src/AboutUs/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/AboutUs/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_7___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_7__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/AboutUs/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_6__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 57,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Feature4__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Feature4_0",
                  key: "Feature4_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_6__[
                      "Feature40DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 63,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content13_0",
                  key: "Content13_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_6__[
                      "Content130DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 69,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content13_1",
                  key: "Content13_1",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_6__[
                      "Content131DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 75,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content13_2",
                  key: "Content13_2",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_6__[
                      "Content132DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 81,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content11__WEBPACK_IMPORTED_MODULE_5__["default"],
                {
                  id: "Content11_0",
                  key: "Content11_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_6__[
                      "Content110DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 87,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 95,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/AboutUs/less/antMotionStyle.less":
      /*!**********************************************!*\
    !*** ./src/AboutUs/less/antMotionStyle.less ***!
    \**********************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/AboutUs/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/AboutUs/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/AboutUs/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/AboutUs/utils.js":
      /*!******************************!*\
    !*** ./src/AboutUs/utils.js ***!
    \******************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/App.js":
      /*!********************!*\
    !*** ./src/App.js ***!
    \********************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! react-router-dom */ "./node_modules/react-router-dom/dist/index.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var _Common_Footer1__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! ./Common/Footer1 */ "./src/Common/Footer1.jsx"
          );
        /* harmony import */ var _Home__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./Home */ "./src/Home/index.jsx");
        /* harmony import */ var _AboutUs__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(/*! ./AboutUs */ "./src/AboutUs/index.jsx");
        /* harmony import */ var _ContactUs__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(/*! ./ContactUs */ "./src/ContactUs/index.jsx");
        /* harmony import */ var _TermsAndConditions__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! ./TermsAndConditions */ "./src/TermsAndConditions/index.jsx"
          );
        /* harmony import */ var _PrivacyPolicy__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(
            /*! ./PrivacyPolicy */ "./src/PrivacyPolicy/index.jsx"
          );
        /* harmony import */ var _Faq__WEBPACK_IMPORTED_MODULE_9__ =
          __webpack_require__(/*! ./Faq */ "./src/Faq/index.jsx");
        /* harmony import */ var _Login__WEBPACK_IMPORTED_MODULE_10__ =
          __webpack_require__(/*! ./Login */ "./src/Login/index.jsx");
        /* harmony import */ var _Signup__WEBPACK_IMPORTED_MODULE_11__ =
          __webpack_require__(/*! ./Signup */ "./src/Signup/index.jsx");
        /* harmony import */ var _PageNotFound__WEBPACK_IMPORTED_MODULE_12__ =
          __webpack_require__(
            /*! ./PageNotFound */ "./src/PageNotFound/index.jsx"
          );
        /* harmony import */ var _Common_data_source_js__WEBPACK_IMPORTED_MODULE_13__ =
          __webpack_require__(
            /*! ./Common/data.source.js */ "./src/Common/data.source.js"
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/App.js";

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_2__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        class App extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
            };
          }
          componentDidMount() {
            // Support for mobile resolutions
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_2__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: b,
                });
              }
            );
          }
          render() {
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              react_router_dom__WEBPACK_IMPORTED_MODULE_1__["BrowserRouter"],
              {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 36,
                  columnNumber: 7,
                },
              },
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                "div",
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 37,
                    columnNumber: 9,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                  react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Routes"],
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 38,
                      columnNumber: 11,
                    },
                  },
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _Home__WEBPACK_IMPORTED_MODULE_4__["default"],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 44,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 39,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/about-us",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _AboutUs__WEBPACK_IMPORTED_MODULE_5__["default"],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 40,
                              columnNumber: 52,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 40,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/contact-us",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _ContactUs__WEBPACK_IMPORTED_MODULE_6__["default"],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 41,
                              columnNumber: 54,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 41,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/terms-and-conditions",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _TermsAndConditions__WEBPACK_IMPORTED_MODULE_7__[
                            "default"
                          ],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 45,
                              columnNumber: 24,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 42,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/privacy-policy",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _PrivacyPolicy__WEBPACK_IMPORTED_MODULE_8__[
                            "default"
                          ],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 58,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 47,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/faq",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _Faq__WEBPACK_IMPORTED_MODULE_9__["default"],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 48,
                              columnNumber: 47,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 48,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/login",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _Login__WEBPACK_IMPORTED_MODULE_10__["default"],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 49,
                              columnNumber: 49,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 49,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/signup",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _Signup__WEBPACK_IMPORTED_MODULE_11__["default"],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 50,
                              columnNumber: 50,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 50,
                        columnNumber: 13,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"],
                    {
                      exact: true,
                      path: "/*",
                      element:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          _PageNotFound__WEBPACK_IMPORTED_MODULE_12__[
                            "default"
                          ],
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 45,
                            },
                          }
                        ),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 51,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                  _Common_Footer1__WEBPACK_IMPORTED_MODULE_3__["default"],
                  {
                    dataSource:
                      _Common_data_source_js__WEBPACK_IMPORTED_MODULE_13__[
                        "Footer10DataSource"
                      ],
                    isMobile: this.isMobile,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 53,
                      columnNumber: 11,
                    },
                  }
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = App;

        /***/
      },

    /***/ "./src/Common/Footer1.jsx":
      /*!********************************!*\
    !*** ./src/Common/Footer1.jsx ***!
    \********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(/*! ./utils */ "./src/Common/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Common/Footer1.jsx";

        class Footer extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .Component {
          constructor() {
            super(...arguments);
            this.getLiChildren = (data) =>
              data.map((item, i) => {
                const { title, childWrapper, ...itemProps } = item;
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      key: i.toString(),
                    },
                    itemProps,
                    {
                      title: null,
                      content: null,
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 18,
                        columnNumber: 9,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "h2",
                    Object.assign({}, title, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 19,
                        columnNumber: 11,
                      },
                    }),
                    typeof title.children === "string" &&
                      title.children.match(
                        _utils__WEBPACK_IMPORTED_MODULE_8__["isImg"]
                      )
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                          "img",
                          {
                            src: title.children,
                            width: "100%",
                            alt: "img",
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 22,
                              columnNumber: 15,
                            },
                          }
                        )
                      : title.children
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "div",
                    Object.assign({}, childWrapper, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 27,
                        columnNumber: 11,
                      },
                    }),
                    childWrapper.children.map(
                      _utils__WEBPACK_IMPORTED_MODULE_8__["getChildrenToRender"]
                    )
                  )
                );
              });
          }
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            const childrenToRender = this.getLiChildren(
              dataSource.block.children
            );
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 41,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default.a,
                Object.assign({}, dataSource.OverPack, {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 42,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_queue_anim__WEBPACK_IMPORTED_MODULE_7__["default"],
                  Object.assign(
                    {
                      type: "bottom",
                      key: "ul",
                      leaveReverse: true,
                      component:
                        antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                    },
                    dataSource.block,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 43,
                        columnNumber: 11,
                      },
                    }
                  ),
                  childrenToRender
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                  Object.assign(
                    {
                      animation: {
                        y: "+=30",
                        opacity: 0,
                        type: "from",
                      },
                      key: "copyright",
                    },
                    dataSource.copyrightWrapper,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 52,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.copyrightPage, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 57,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "div",
                      Object.assign({}, dataSource.copyright, {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 58,
                          columnNumber: 15,
                        },
                      }),
                      dataSource.copyright.children
                    )
                  )
                )
              )
            );
          }
        }
        Footer.defaultProps = {
          className: "footer1",
        };
        /* harmony default export */ __webpack_exports__["default"] = Footer;

        /***/
      },

    /***/ "./src/Common/data.source.js":
      /*!***********************************!*\
    !*** ./src/Common/data.source.js ***!
    \***********************************/
      /*! exports provided: Footer10DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Footer10DataSource",
          function () {
            return Footer10DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Common/data.source.js";

        const Footer10DataSource = {
          wrapper: {
            className: "home-page-wrapper footer1-wrapper",
          },
          OverPack: {
            className: "footer1",
            playScale: 0.2,
          },
          block: {
            className: "home-page",
            gutter: 0,
            children: [
              {
                name: "block0",
                xs: 24,
                md: 6,
                className: "block",
                title: {
                  className: "logo",
                  children:
                    "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
                },
                childWrapper: {
                  className: "slogan",
                  children: [
                    {
                      name: "content0",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 25,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 26,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "span",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 27,
                                  columnNumber: 21,
                                },
                              },
                              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                "p",
                                {
                                  __self: undefined,
                                  __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 28,
                                    columnNumber: 23,
                                  },
                                },
                                "World's Leading Free-to-use role-play facilitator",
                                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                  "br",
                                  {
                                    __self: undefined,
                                    __source: {
                                      fileName: _jsxFileName,
                                      lineNumber: 30,
                                      columnNumber: 25,
                                    },
                                  }
                                )
                              )
                            )
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block1",
                xs: 24,
                md: 6,
                className: "block",
                title: {
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 47,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 48,
                            columnNumber: 15,
                          },
                        },
                        "Information"
                      )
                    ),
                },
                childWrapper: {
                  children: [
                    {
                      name: "link0",
                      href: "https://github.com/Linesmerrill/police-cad/releases",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 58,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 59,
                                columnNumber: 19,
                              },
                            },
                            "Release Log",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 61,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      target: "",
                    },
                    {
                      name: "link1",
                      href: "https://linesmerrill.github.io/MerrillLines/",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 71,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 72,
                                columnNumber: 19,
                              },
                            },
                            "Developers"
                          )
                        ),
                    },
                    {
                      href: "https://www.patreon.com/linespolicecad",
                      name: "link2",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 80,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 81,
                                columnNumber: 19,
                              },
                            },
                            "Patreon"
                          )
                        ),
                      target: "_blank",
                    },
                    {
                      href: "https://github.com/linesmerrill/police-cad",
                      name: "link3",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 90,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 91,
                                columnNumber: 19,
                              },
                            },
                            "GitHub"
                          )
                        ),
                      target: "_blank",
                    },
                  ],
                },
              },
              {
                name: "block2",
                xs: 24,
                md: 6,
                className: "block",
                title: {
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 106,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 107,
                            columnNumber: 15,
                          },
                        },
                        "About"
                      )
                    ),
                },
                childWrapper: {
                  children: [
                    {
                      href: "/faq",
                      name: "link0",
                      children: "FAQ",
                    },
                    {
                      href: "/contact-us",
                      name: "link1",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 118,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 119,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 121,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                    {
                      name: "link2",
                      href: "/terms-and-conditions",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 130,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 131,
                                columnNumber: 19,
                              },
                            },
                            "Terms and Conditions"
                          )
                        ),
                    },
                    {
                      name: "link3",
                      href: "/privacy-policy",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 139,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 140,
                                columnNumber: 19,
                              },
                            },
                            "Privacy Policy"
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block3",
                xs: 24,
                md: 6,
                className: "block",
                title: {
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 154,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 155,
                            columnNumber: 15,
                          },
                        },
                        "Follow"
                      )
                    ),
                },
                childWrapper: {
                  children: [
                    {
                      href: "https://discord.gg/3ECFhqe",
                      name: "link0",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 165,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 166,
                                columnNumber: 19,
                              },
                            },
                            "Discord"
                          )
                        ),
                      target: "_blank",
                    },
                    {
                      href: "https://twitter.com/LinesPoliceCAD",
                      name: "link1",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 175,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 176,
                                columnNumber: 19,
                              },
                            },
                            "Twitter"
                          )
                        ),
                      target: "_blank",
                    },
                    {
                      href: "https://www.facebook.com/linespoliceserver/",
                      name: "link2",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 185,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 186,
                                columnNumber: 19,
                              },
                            },
                            "Facebook"
                          )
                        ),
                      target: "_blank",
                    },
                  ],
                },
              },
            ],
          },
          copyrightWrapper: {
            className: "copyright-wrapper",
          },
          copyrightPage: {
            className: "home-page",
          },
          copyright: {
            className: "copyright",
            children:
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                "span",
                {
                  __self: undefined,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 201,
                    columnNumber: 7,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                  "span",
                  {
                    __self: undefined,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 202,
                      columnNumber: 9,
                    },
                  },
                  "\xA92023 by",
                  " ",
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "a",
                    {
                      href: "https://sites.google.com/view/tlps-dev/home",
                      target: "_blank",
                      rel: "noopener noreferrer",
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 204,
                        columnNumber: 11,
                      },
                    },
                    "TLPS"
                  ),
                  " ",
                  "All Rights Reserved"
                )
              ),
          },
        };

        /***/
      },

    /***/ "./src/Common/utils.js":
      /*!*****************************!*\
    !*** ./src/Common/utils.js ***!
    \*****************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/ContactUs/Content11.jsx":
      /*!*************************************!*\
    !*** ./src/ContactUs/Content11.jsx ***!
    \*************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(/*! ./utils */ "./src/ContactUs/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/ContactUs/Content11.jsx";

        class Content11 extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_3___default.a,
              Object.assign({}, props, dataSource.OverPack, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__["default"],
                Object.assign(
                  {
                    type: "bottom",
                    leaveReverse: true,
                    key: "page",
                    delay: [0, 100],
                  },
                  dataSource.titleWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 16,
                      columnNumber: 9,
                    },
                  }
                ),
                dataSource.titleWrapper.children.map(
                  _utils__WEBPACK_IMPORTED_MODULE_6__["getChildrenToRender"]
                )
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                Object.assign(
                  {
                    key: "button",
                    style: {
                      textAlign: "center",
                    },
                  },
                  dataSource.button,
                  {
                    animation: {
                      y: 30,
                      opacity: 0,
                      type: "from",
                      delay: 300,
                    },
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 25,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                  Object.assign({}, dataSource.button.children.a, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 31,
                      columnNumber: 11,
                    },
                  }),
                  dataSource.button.children.a.children
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content11;

        /***/
      },

    /***/ "./src/ContactUs/Content13.jsx":
      /*!*************************************!*\
    !*** ./src/ContactUs/Content13.jsx ***!
    \*************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./utils */ "./src/ContactUs/utils.js");
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/ContactUs/Content13.jsx";

        class Content13 extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default.a,
              Object.assign({}, props, dataSource.OverPack, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 13,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__["default"],
                Object.assign(
                  {
                    type: "bottom",
                    leaveReverse: true,
                    key: "page",
                    delay: [0, 100],
                  },
                  dataSource.titleWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 14,
                      columnNumber: 9,
                    },
                  }
                ),
                dataSource.titleWrapper.children.map(
                  _utils__WEBPACK_IMPORTED_MODULE_3__["getChildrenToRender"]
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content13;

        /***/
      },

    /***/ "./src/ContactUs/Nav0.jsx":
      /*!********************************!*\
    !*** ./src/ContactUs/Nav0.jsx ***!
    \********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/ContactUs/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/ContactUs/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/ContactUs/data.source.js":
      /*!**************************************!*\
    !*** ./src/ContactUs/data.source.js ***!
    \**************************************/
      /*! exports provided: Nav00DataSource, Content130DataSource, Content111DataSource, Content110DataSource, Content112DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content130DataSource",
          function () {
            return Content130DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content111DataSource",
          function () {
            return Content111DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content110DataSource",
          function () {
            return Content110DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content112DataSource",
          function () {
            return Content112DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/ContactUs/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Content130DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj33686irk-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 129,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 130,
                          columnNumber: 13,
                        },
                      },
                      "Contact Us",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 131,
                            columnNumber: 25,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
            ],
          },
        };
        const Content111DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content11-wrapper lj33d6mkz09-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 157,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 158,
                          columnNumber: 13,
                        },
                      },
                      "Reach out to Us",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 159,
                            columnNumber: 30,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 168,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 169,
                          columnNumber: 13,
                        },
                      },
                      "Need direct support? Shoot us an email and we will get back to you as soon as possible.",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 171,
                            columnNumber: 35,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 180,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "br",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 181,
                          columnNumber: 13,
                        },
                      }
                    )
                  ),
                className: "title-content",
              },
            ],
          },
          button: {
            className: "",
            children: {
              a: {
                className: "button",
                href: "mailto:support@linespolice-cad.com",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 195,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 196,
                          columnNumber: 13,
                        },
                      },
                      "Email"
                    )
                  ),
                target: "_blank",
              },
            },
          },
        };
        const Content110DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content11-wrapper lj3383x3tjr-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 221,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 222,
                          columnNumber: 13,
                        },
                      },
                      "Request a New Feature",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 223,
                            columnNumber: 36,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 232,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 233,
                          columnNumber: 13,
                        },
                      },
                      "Is there something missing that you wish we could do? Click here to request something new. We actively review all feature requests.",
                      " ",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 236,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 245,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 246,
                          columnNumber: 13,
                        },
                      },
                      "Note: Before creating a new request, double check it doesn't already exist.",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 248,
                            columnNumber: 29,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
            ],
          },
          button: {
            className: "",
            children: {
              a: {
                className: "button",
                href: "#",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 263,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 264,
                          columnNumber: 13,
                        },
                      },
                      "Request Feature",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 265,
                            columnNumber: 30,
                          },
                        }
                      )
                    )
                  ),
              },
            },
          },
        };
        const Content112DataSource = {
          OverPack: {
            className: "home-page-wrapper content11-wrapper",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 290,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 291,
                          columnNumber: 13,
                        },
                      },
                      "Report a Bug",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 292,
                            columnNumber: 27,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 301,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 302,
                          columnNumber: 13,
                        },
                      },
                      "We do our best to avoid bugs, but they are inevitable. Click here to report one.",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 304,
                            columnNumber: 29,
                          },
                        }
                      )
                    )
                  ),
                className: "title-content",
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 313,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 314,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 315,
                            columnNumber: 15,
                          },
                        },
                        "(We love squashing bugs, so by reporting you may even get a shout-out on our socials)",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 317,
                              columnNumber: 42,
                            },
                          }
                        )
                      )
                    )
                  ),
                className: "title-content",
              },
            ],
          },
          button: {
            className: "",
            children: {
              a: {
                className: "button",
                href: "https://github.com/Linesmerrill/police-cad/issues/new?assignees=&labels=&template=bug_report.md&title=",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 334,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 335,
                          columnNumber: 13,
                        },
                      },
                      "Report Bug",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 336,
                            columnNumber: 25,
                          },
                        }
                      )
                    )
                  ),
                target: "_blank",
              },
            },
          },
        };

        /***/
      },

    /***/ "./src/ContactUs/index.jsx":
      /*!*********************************!*\
    !*** ./src/ContactUs/index.jsx ***!
    \*********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/ContactUs/Nav0.jsx");
        /* harmony import */ var _Content13__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! ./Content13 */ "./src/ContactUs/Content13.jsx"
          );
        /* harmony import */ var _Content11__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./Content11 */ "./src/ContactUs/Content11.jsx"
          );
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./data.source */ "./src/ContactUs/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/ContactUs/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_6___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_6__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/ContactUs/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_5__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 55,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Content13_0",
                  key: "Content13_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_5__[
                      "Content130DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 61,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content11__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content11_1",
                  key: "Content11_1",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_5__[
                      "Content111DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 67,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content11__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content11_0",
                  key: "Content11_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_5__[
                      "Content110DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content11__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content11_2",
                  key: "Content11_2",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_5__[
                      "Content112DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 79,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/ContactUs/less/antMotionStyle.less":
      /*!************************************************!*\
    !*** ./src/ContactUs/less/antMotionStyle.less ***!
    \************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/ContactUs/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/ContactUs/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/ContactUs/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/ContactUs/utils.js":
      /*!********************************!*\
    !*** ./src/ContactUs/utils.js ***!
    \********************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/Faq/Feature4.jsx":
      /*!******************************!*\
    !*** ./src/Faq/Feature4.jsx ***!
    \******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(/*! ./utils */ "./src/Faq/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Faq/Feature4.jsx";

        class Content7 extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .Component {
          constructor() {
            super(...arguments);
            this.getBlockChildren = (data) =>
              data.map(($item) => {
                const { ...item } = $item;
                const { title, img, content } = item;
                ["title", "img", "content"].forEach((key) => delete item[key]);
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "li",
                  Object.assign(
                    {
                      key: item.name,
                    },
                    item,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 15,
                        columnNumber: 9,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "span",
                    Object.assign({}, img, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 16,
                        columnNumber: 11,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "img",
                      {
                        src: img.children,
                        width: "100%",
                        alt: "img",
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 17,
                          columnNumber: 13,
                        },
                      }
                    )
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "h2",
                    Object.assign({}, title, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 19,
                        columnNumber: 11,
                      },
                    }),
                    title.children
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "div",
                    Object.assign({}, content, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 20,
                        columnNumber: 11,
                      },
                    }),
                    content.children
                  )
                );
              });
          }
          render() {
            const { ...props } = this.props;
            const { dataSource, isMobile } = props;
            delete props.dataSource;
            delete props.isMobile;
            const ulChildren = this.getBlockChildren(dataSource.block.children);
            const queue = isMobile ? "bottom" : "left";
            const imgAnim = isMobile
              ? {
                  y: 30,
                  opacity: 0,
                  delay: 600,
                  type: "from",
                  ease: "easeOutQuad",
                }
              : {
                  x: 30,
                  opacity: 0,
                  type: "from",
                  ease: "easeOutQuad",
                };
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 47,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default.a,
                Object.assign({}, dataSource.OverPack, {
                  component:
                    antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 48,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_queue_anim__WEBPACK_IMPORTED_MODULE_6__["default"],
                  Object.assign(
                    {
                      key: "text",
                      type: queue,
                      leaveReverse: true,
                      ease: ["easeOutQuad", "easeInQuad"],
                    },
                    dataSource.textWrapper,
                    {
                      component:
                        antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 49,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "div",
                    Object.assign(
                      {
                        key: "title",
                      },
                      dataSource.titleWrapper,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 57,
                          columnNumber: 13,
                        },
                      }
                    ),
                    dataSource.titleWrapper.children.map(
                      _utils__WEBPACK_IMPORTED_MODULE_8__["getChildrenToRender"]
                    )
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_queue_anim__WEBPACK_IMPORTED_MODULE_6__["default"],
                    Object.assign(
                      {
                        component: "ul",
                        key: "ul",
                        type: queue,
                        ease: "easeOutQuad",
                      },
                      dataSource.block,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 60,
                          columnNumber: 13,
                        },
                      }
                    ),
                    ulChildren
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                  Object.assign(
                    {
                      key: "img",
                      animation: imgAnim,
                      resetStyle: true,
                    },
                    dataSource.img,
                    {
                      component:
                        antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 70,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "img",
                    {
                      src: dataSource.img.children,
                      width: "100%",
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 77,
                        columnNumber: 13,
                      },
                    }
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content7;

        /***/
      },

    /***/ "./src/Faq/Nav0.jsx":
      /*!**************************!*\
    !*** ./src/Faq/Nav0.jsx ***!
    \**************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/Faq/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Faq/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/Faq/data.source.js":
      /*!********************************!*\
    !*** ./src/Faq/data.source.js ***!
    \********************************/
      /*! exports provided: Nav00DataSource, Feature40DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Feature40DataSource",
          function () {
            return Feature40DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Faq/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Feature40DataSource = {
          wrapper: {
            className: "home-page-wrapper content6-wrapper",
          },
          OverPack: {
            className: "home-page content6",
          },
          textWrapper: {
            className: "content6-text",
            xs: 24,
            md: 10,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 122,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 123,
                          columnNumber: 13,
                        },
                      },
                      "FAQs"
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                className: "title-content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 132,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "br",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 133,
                          columnNumber: 13,
                        },
                      }
                    )
                  ),
              },
            ],
          },
          img: {
            children:
              "https://www.linespolice-cad.com/static/images/faq-logo-512.png",
            className: "content6-img",
            xs: 24,
            md: 14,
          },
          block: {
            children: [
              {
                name: "block0",
                img: {
                  children:
                    "https://zos.alipayobjects.com/rmsportal/NKBELAOuuKbofDD.png",
                  className: "content6-icon",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 157,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 158,
                            columnNumber: 15,
                          },
                        },
                        "Can I use this for XBox and Playstation games?"
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 165,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 166,
                            columnNumber: 15,
                          },
                        },
                        "Yup! Players on consoles make up the majority of our users."
                      )
                    ),
                },
              },
              {
                name: "block1",
                img: {
                  className: "content6-icon",
                  children:
                    "https://zos.alipayobjects.com/rmsportal/xMSBjgxBhKfyMWX.png",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 181,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 182,
                            columnNumber: 15,
                          },
                        },
                        "Where do I go to report a bug?"
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 189,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 190,
                            columnNumber: 15,
                          },
                        },
                        "You can report bugs",
                        " ",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "https://github.com/Linesmerrill/police-cad/issues/new?assignees=&labels=&projects=&template=bug_report.md&title=",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 192,
                              columnNumber: 17,
                            },
                          },
                          "here"
                        ),
                        ". We will take a look at work to fix it as soon as possible"
                      )
                    ),
                },
              },
              {
                name: "block2",
                img: {
                  className: "content6-icon",
                  children:
                    "https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 215,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 216,
                            columnNumber: 15,
                          },
                        },
                        "How do I create/join a community?"
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 223,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 224,
                            columnNumber: 15,
                          },
                        },
                        "Navigate to our ",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "/communities",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 225,
                              columnNumber: 33,
                            },
                          },
                          "community page"
                        ),
                        " and click on 'Join' or 'Create'."
                      )
                    ),
                },
              },
              {
                name: "block~lj7rziivd3",
                img: {
                  className: "content6-icon",
                  children:
                    "https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png",
                },
                title: {
                  className: "content6-title",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 242,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 243,
                            columnNumber: 15,
                          },
                        },
                        "Is this really free?",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 245,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
                content: {
                  className: "content6-content",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 253,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 254,
                            columnNumber: 15,
                          },
                        },
                        "Yes! This is 100% free to use. We do run some ads to help support the server and development costs."
                      )
                    ),
                },
              },
            ],
          },
        };

        /***/
      },

    /***/ "./src/Faq/index.jsx":
      /*!***************************!*\
    !*** ./src/Faq/index.jsx ***!
    \***************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/Faq/Nav0.jsx");
        /* harmony import */ var _Feature4__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./Feature4 */ "./src/Faq/Feature4.jsx");
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./data.source */ "./src/Faq/data.source.js");
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/Faq/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Faq/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 48,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Feature4__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Feature4_0",
                  key: "Feature4_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Feature40DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 54,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/Faq/less/antMotionStyle.less":
      /*!******************************************!*\
    !*** ./src/Faq/less/antMotionStyle.less ***!
    \******************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Faq/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Faq/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Faq/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/Faq/utils.js":
      /*!**************************!*\
    !*** ./src/Faq/utils.js ***!
    \**************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/Home/Banner0.jsx":
      /*!******************************!*\
    !*** ./src/Home/Banner0.jsx ***!
    \******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js"
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(/*! ./utils */ "./src/Home/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/Banner0.jsx";

        class Banner extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .PureComponent {
          render() {
            const { ...currentProps } = this.props;
            const { dataSource } = currentProps;
            delete currentProps.dataSource;
            delete currentProps.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              "div",
              Object.assign({}, currentProps, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__["default"],
                Object.assign(
                  {
                    key: "QueueAnim",
                    type: ["bottom", "top"],
                    delay: 200,
                  },
                  dataSource.textWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 16,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "div",
                  Object.assign(
                    {
                      key: "title",
                    },
                    dataSource.title,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 22,
                        columnNumber: 11,
                      },
                    }
                  ),
                  typeof dataSource.title.children === "string" &&
                    dataSource.title.children.match(
                      _utils__WEBPACK_IMPORTED_MODULE_6__["isImg"]
                    )
                    ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                        "img",
                        {
                          src: dataSource.title.children,
                          width: "100%",
                          alt: "img",
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 25,
                            columnNumber: 15,
                          },
                        }
                      )
                    : dataSource.title.children
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "div",
                  Object.assign(
                    {
                      key: "content",
                    },
                    dataSource.content,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 30,
                        columnNumber: 11,
                      },
                    }
                  ),
                  dataSource.content.children
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                  Object.assign(
                    {
                      ghost: true,
                      key: "button",
                    },
                    dataSource.button,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 33,
                        columnNumber: 11,
                      },
                    }
                  ),
                  dataSource.button.children
                )
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                {
                  animation: {
                    y: "-=20",
                    yoyo: true,
                    repeat: -1,
                    duration: 1000,
                  },
                  className: "banner0-icon",
                  key: "icon",
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 37,
                    columnNumber: 9,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__[
                    "DownOutlined"
                  ],
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 47,
                      columnNumber: 11,
                    },
                  }
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Banner;

        /***/
      },

    /***/ "./src/Home/Content0.jsx":
      /*!*******************************!*\
    !*** ./src/Home/Content0.jsx ***!
    \*******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(/*! ./utils */ "./src/Home/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/Content0.jsx";

        class Content extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .PureComponent {
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const {
              wrapper,
              titleWrapper,
              page,
              OverPack: overPackData,
              childWrapper,
            } = dataSource;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 18,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                "div",
                Object.assign({}, page, {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 19,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "div",
                  Object.assign({}, titleWrapper, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 20,
                      columnNumber: 11,
                    },
                  }),
                  titleWrapper.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_7__["getChildrenToRender"]
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default.a,
                  Object.assign({}, overPackData, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 23,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_queue_anim__WEBPACK_IMPORTED_MODULE_5__["default"],
                    {
                      type: "bottom",
                      key: "block",
                      leaveReverse: true,
                      component:
                        antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                      componentProps: childWrapper,
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 24,
                        columnNumber: 13,
                      },
                    },
                    childWrapper.children.map((block, i) => {
                      const { children: item, ...blockProps } = block;
                      return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                        antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                        Object.assign(
                          {
                            key: i.toString(),
                          },
                          blockProps,
                          {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 34,
                              columnNumber: 19,
                            },
                          }
                        ),
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                          "div",
                          Object.assign({}, item, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 21,
                            },
                          }),
                          item.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_7__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      );
                    })
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content;

        /***/
      },

    /***/ "./src/Home/Content3.jsx":
      /*!*******************************!*\
    !*** ./src/Home/Content3.jsx ***!
    \*******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(/*! ./utils */ "./src/Home/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/Content3.jsx";

        class Content3 extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .PureComponent {
          constructor() {
            super(...arguments);
            this.getDelay = (e, b) =>
              (e % b) * 100 + Math.floor(e / b) * 100 + b * 100;
          }
          render() {
            const { ...props } = this.props;
            const { dataSource, isMobile } = props;
            delete props.dataSource;
            delete props.isMobile;
            let clearFloatNum = 0;
            const children = dataSource.block.children.map((item, i) => {
              const childObj = item.children;
              const delay = isMobile ? i * 50 : this.getDelay(i, 24 / item.md);
              const liAnim = {
                opacity: 0,
                type: "from",
                ease: "easeOutQuad",
                delay,
              };
              const childrenAnim = {
                ...liAnim,
                x: "+=10",
                delay: delay + 100,
              };
              clearFloatNum += item.md;
              clearFloatNum = clearFloatNum > 24 ? 0 : clearFloatNum;
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                rc_tween_one__WEBPACK_IMPORTED_MODULE_6__["default"],
                Object.assign(
                  {
                    component:
                      antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                    animation: liAnim,
                    key: item.name,
                  },
                  item,
                  {
                    componentProps: {
                      md: item.md,
                      xs: item.xs,
                    },
                    className: !clearFloatNum
                      ? `${item.className || ""} clear-both`.trim()
                      : item.className,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 30,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_6__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: "-=10",
                        opacity: 0,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                      key: "img",
                    },
                    childObj.icon,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 42,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "img",
                    {
                      src: childObj.icon.children,
                      width: "100%",
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 52,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "div",
                  Object.assign({}, childObj.textWrapper, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 54,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_tween_one__WEBPACK_IMPORTED_MODULE_6__["default"],
                    Object.assign(
                      {
                        key: "h2",
                        animation: childrenAnim,
                        component: "h2",
                      },
                      childObj.title,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 55,
                          columnNumber: 13,
                        },
                      }
                    ),
                    childObj.title.children
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_tween_one__WEBPACK_IMPORTED_MODULE_6__["default"],
                    Object.assign(
                      {
                        key: "p",
                        animation: {
                          ...childrenAnim,
                          delay: delay + 200,
                        },
                        component: "div",
                      },
                      childObj.content,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 63,
                          columnNumber: 13,
                        },
                      }
                    ),
                    childObj.content.children
                  )
                )
              );
            });
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 76,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 77,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "div",
                  Object.assign({}, dataSource.titleWrapper, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 78,
                      columnNumber: 11,
                    },
                  }),
                  dataSource.titleWrapper.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_8__["getChildrenToRender"]
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default.a,
                  Object.assign({}, dataSource.OverPack, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 81,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_queue_anim__WEBPACK_IMPORTED_MODULE_5__["default"],
                    {
                      key: "u",
                      type: "bottom",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 82,
                        columnNumber: 13,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                      Object.assign(
                        {
                          key: "row",
                        },
                        dataSource.block,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 83,
                            columnNumber: 15,
                          },
                        }
                      ),
                      children
                    )
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content3;

        /***/
      },

    /***/ "./src/Home/Feature6.jsx":
      /*!*******************************!*\
    !*** ./src/Home/Feature6.jsx ***!
    \*******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_carousel_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/carousel/style */ "./node_modules/antd/es/carousel/style/index.js"
          );
        /* harmony import */ var antd_es_carousel__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/carousel */ "./node_modules/antd/es/carousel/index.js"
          );
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_6__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_9__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_tween_one_lib_plugin_ChildrenPlugin__WEBPACK_IMPORTED_MODULE_10__ =
          __webpack_require__(
            /*! rc-tween-one/lib/plugin/ChildrenPlugin */ "./node_modules/rc-tween-one/lib/plugin/ChildrenPlugin.js"
          );
        /* harmony import */ var rc_tween_one_lib_plugin_ChildrenPlugin__WEBPACK_IMPORTED_MODULE_10___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_tween_one_lib_plugin_ChildrenPlugin__WEBPACK_IMPORTED_MODULE_10__
          );

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/Feature6.jsx";

        rc_tween_one__WEBPACK_IMPORTED_MODULE_9__["default"].plugins.push(
          rc_tween_one_lib_plugin_ChildrenPlugin__WEBPACK_IMPORTED_MODULE_10___default.a
        );
        class Feature6 extends react__WEBPACK_IMPORTED_MODULE_6___default.a
          .PureComponent {
          constructor(props) {
            super(props);
            this.onTitleClick = (_, i) => {
              const carouselRef = this.carouselRef.current.childRefs.carousel;
              carouselRef.goTo(i);
            };
            this.onBeforeChange = (_, newIndex) => {
              this.setState({
                current: newIndex,
              });
            };
            this.getChildrenToRender = (dataSource) => {
              const { current } = this.state;
              const { Carousel } = dataSource;
              const {
                titleWrapper,
                children: childWrapper,
                wrapper,
                ...carouselProps
              } = Carousel;
              const {
                barWrapper,
                title: titleChild,
                ...titleWrapperProps
              } = titleWrapper;
              const titleToRender = [];
              const childrenToRender = childWrapper.map((item, ii) => {
                const { title, children, ...itemProps } = item;
                titleToRender.push(
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                    "div",
                    Object.assign({}, title, {
                      key: ii.toString(),
                      onClick: (e) => {
                        this.onTitleClick(e, ii);
                      },
                      className:
                        ii === current
                          ? `${title.className || ""} active`
                          : title.className,
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 50,
                        columnNumber: 9,
                      },
                    }),
                    title.children
                  )
                );
                const childrenItem = children.map(($item, i) => {
                  const { number, children: child, ...childProps } = $item;
                  const numberChild = number.children.replace(/[^0-9.-]/g, "");
                  const { unit, toText, ...numberProps } = number;
                  return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                    antd_es_col__WEBPACK_IMPORTED_MODULE_5__["default"],
                    Object.assign({}, childProps, {
                      key: i.toString(),
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 68,
                        columnNumber: 11,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                      rc_tween_one__WEBPACK_IMPORTED_MODULE_9__["default"],
                      Object.assign({}, numberProps, {
                        animation: {
                          Children: {
                            value: parseFloat(numberChild),
                            floatLength:
                              parseFloat(numberChild) -
                                Math.floor(parseFloat(numberChild)) >
                              0
                                ? 2
                                : 0,
                            formatMoney: true,
                          },
                          duration: 1000,
                          delay: 300,
                          ease: "easeInOutCirc",
                        },
                        component: "span",
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 69,
                          columnNumber: 13,
                        },
                      }),
                      "0"
                    ),
                    unit &&
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                        "span",
                        Object.assign({}, unit, {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 90,
                            columnNumber: 22,
                          },
                        }),
                        unit.children
                      ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                      "p",
                      Object.assign({}, child, {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 91,
                          columnNumber: 13,
                        },
                      }),
                      child.children
                    )
                  );
                });
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                  "div",
                  {
                    key: ii.toString(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 96,
                      columnNumber: 9,
                    },
                  },
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                    rc_queue_anim__WEBPACK_IMPORTED_MODULE_8__["default"],
                    Object.assign(
                      {
                        type: "bottom",
                        component:
                          antd_es_row__WEBPACK_IMPORTED_MODULE_3__["default"],
                      },
                      itemProps,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 11,
                        },
                      }
                    ),
                    childrenItem
                  )
                );
              });
              const width = 100 / childrenToRender.length;
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_8__["default"],
                Object.assign(
                  {
                    key: "queue",
                    leaveReverse: true,
                    type: "bottom",
                    delay: [0, 100],
                  },
                  wrapper,
                  {
                    ref: this.carouselRef,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 106,
                      columnNumber: 7,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                  "div",
                  Object.assign({}, titleWrapperProps, {
                    key: "title",
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 114,
                      columnNumber: 9,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                    "div",
                    Object.assign({}, titleChild, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 115,
                        columnNumber: 11,
                      },
                    }),
                    titleToRender,
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                      "div",
                      Object.assign({}, barWrapper, {
                        style: {
                          width: `${width}%`,
                          left: `${width * current}%`,
                        },
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 117,
                          columnNumber: 13,
                        },
                      }),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                        "em",
                        Object.assign({}, barWrapper.children, {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 124,
                            columnNumber: 15,
                          },
                        })
                      )
                    )
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                  antd_es_carousel__WEBPACK_IMPORTED_MODULE_1__["default"],
                  Object.assign({}, carouselProps, {
                    key: "carousel",
                    infinite: false,
                    beforeChange: this.onBeforeChange,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 128,
                      columnNumber: 9,
                    },
                  }),
                  childrenToRender
                )
              );
            };
            this.carouselRef =
              react__WEBPACK_IMPORTED_MODULE_6___default.a.createRef();
            this.state = {
              current: 0,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 143,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                "div",
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 144,
                    columnNumber: 9,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
                  rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_7___default.a,
                  Object.assign({}, dataSource.OverPack, {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 145,
                      columnNumber: 11,
                    },
                  }),
                  this.getChildrenToRender(dataSource)
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Feature6;

        /***/
      },

    /***/ "./src/Home/Nav0.jsx":
      /*!***************************!*\
    !*** ./src/Home/Nav0.jsx ***!
    \***************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/Home/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/Home/data.source.js":
      /*!*********************************!*\
    !*** ./src/Home/data.source.js ***!
    \*********************************/
      /*! exports provided: Nav00DataSource, Banner01DataSource, Content00DataSource, Feature60DataSource, Content30DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Banner01DataSource",
          function () {
            return Banner01DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content00DataSource",
          function () {
            return Content00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Feature60DataSource",
          function () {
            return Feature60DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content30DataSource",
          function () {
            return Content30DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Banner01DataSource = {
          wrapper: {
            className: "banner0 likygdl71t-editor_css",
          },
          textWrapper: {
            className: "banner0-text-wrapper lig76kd43qs-editor_css",
          },
          title: {
            className: "banner0-title lig76enk3kh-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_main_transparentv2.png",
          },
          content: {
            className: "banner0-content lig7ognf8u-editor_css",
            children:
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                "p",
                {
                  __self: undefined,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 7,
                  },
                },
                "World's Leading Free-to-use service for Role-play communities"
              ),
          },
          button: {
            className: "banner0-button ligdeo3ow6-editor_css",
            children:
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                "span",
                {
                  __self: undefined,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 129,
                    columnNumber: 7,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                  "p",
                  {
                    __self: undefined,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 130,
                      columnNumber: 9,
                    },
                  },
                  "Get Started",
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "br",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 132,
                        columnNumber: 11,
                      },
                    }
                  )
                )
              ),
            href: "/signup",
          },
        };
        const Content00DataSource = {
          wrapper: {
            className: "home-page-wrapper content0-wrapper",
          },
          page: {
            className: "home-page content0",
          },
          OverPack: {
            playScale: 0.3,
            className: "",
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 149,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 150,
                          columnNumber: 13,
                        },
                      },
                      "Dashboards"
                    )
                  ),
              },
            ],
          },
          childWrapper: {
            className: "content0-block-wrapper",
            children: [
              {
                name: "block0",
                className: "content0-block",
                md: 8,
                xs: 24,
                children: {
                  className: "content0-block-item",
                  children: [
                    {
                      name: "image",
                      className: "content0-block-icon",
                      children:
                        "https://www.linespolice-cad.com/static/images/civilian-logo-512.png",
                    },
                    {
                      name: "title",
                      className: "content0-block-title",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 177,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 178,
                                columnNumber: 19,
                              },
                            },
                            "Civilian"
                          )
                        ),
                    },
                    {
                      name: "content",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 185,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 186,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "p",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 187,
                                  columnNumber: 21,
                                },
                              },
                              "Quickly and easily create and manage all your civilians, vehicles, firearms and more",
                              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                "br",
                                {
                                  __self: undefined,
                                  __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 190,
                                    columnNumber: 23,
                                  },
                                }
                              )
                            )
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block1",
                className: "content0-block",
                md: 8,
                xs: 24,
                children: {
                  className: "content0-block-item",
                  children: [
                    {
                      name: "image",
                      className: "content0-block-icon",
                      children:
                        "https://www.linespolice-cad.com/static/images/police-logo-512.png",
                    },
                    {
                      name: "title",
                      className: "content0-block-title",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 217,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 218,
                                columnNumber: 19,
                              },
                            },
                            "Police"
                          )
                        ),
                    },
                    {
                      name: "content",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 225,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 226,
                                columnNumber: 19,
                              },
                            },
                            "Create citations, issue warrants, and mark yourself '10-8' with our snappy police controls",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 229,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block2",
                className: "content0-block",
                md: 8,
                xs: 24,
                children: {
                  className: "content0-block-item",
                  children: [
                    {
                      name: "image",
                      className: "content0-block-icon",
                      children:
                        "https://www.linespolice-cad.com/static/images/dispatch-logo-512.png",
                    },
                    {
                      name: "title",
                      className: "content0-block-title",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 255,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 256,
                                columnNumber: 19,
                              },
                            },
                            "Dispatch"
                          )
                        ),
                    },
                    {
                      name: "content",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 263,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 264,
                                columnNumber: 19,
                              },
                            },
                            "Coordinate all the officers in your community. Set a status, assign officers to calls and much more.",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 267,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block~ligdkrl2f56",
                className: "content0-block",
                md: 8,
                xs: 24,
                children: {
                  className: "content0-block-item",
                  children: [
                    {
                      name: "image",
                      className: "content0-block-icon",
                      children:
                        "https://www.linespolice-cad.com/static/images/ems-logo-512.png",
                    },
                    {
                      name: "title",
                      className: "content0-block-title",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 293,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 294,
                                columnNumber: 19,
                              },
                            },
                            "Fire & EMS",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 296,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                    {
                      name: "content",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 304,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 305,
                                columnNumber: 19,
                              },
                            },
                            "Create a fire or EMS personnel to aid civilians. Access medical history and create medical reports"
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block~ligdktt31z",
                className: "content0-block",
                md: 8,
                xs: 24,
                children: {
                  className: "content0-block-item",
                  children: [
                    {
                      name: "image",
                      className: "content0-block-icon",
                      children:
                        "https://www.linespolice-cad.com/static/images/community-logo-512.png",
                    },
                    {
                      name: "title",
                      className: "content0-block-title",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 333,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 334,
                                columnNumber: 19,
                              },
                            },
                            "Community"
                          )
                        ),
                    },
                    {
                      name: "content",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 341,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 342,
                                columnNumber: 19,
                              },
                            },
                            "Create your own community exclusively for private use of all your own data, civilians and much more"
                          )
                        ),
                    },
                  ],
                },
              },
              {
                name: "block~ligdkwtkuw6",
                className: "content0-block",
                md: 8,
                xs: 24,
                children: {
                  className: "content0-block-item",
                  children: [
                    {
                      name: "image",
                      className: "content0-block-icon",
                      children:
                        "https://www.linespolice-cad.com/static/images/create-your-own-logo-512.png",
                    },
                    {
                      name: "title",
                      className: "content0-block-title",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 370,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 371,
                                columnNumber: 19,
                              },
                            },
                            "Create your own",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 373,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                    {
                      name: "content",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 381,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 382,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "p",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 383,
                                  columnNumber: 21,
                                },
                              },
                              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                "b",
                                {
                                  __self: undefined,
                                  __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 384,
                                    columnNumber: 23,
                                  },
                                },
                                "Coming soon"
                              ),
                              " we will have the ability to create your own department, aside from the default we give you."
                            )
                          )
                        ),
                    },
                  ],
                },
              },
            ],
          },
        };
        const Feature60DataSource = {
          wrapper: {
            className: "home-page-wrapper feature6-wrapper",
          },
          OverPack: {
            className: "home-page feature6",
            playScale: 0.3,
          },
          Carousel: {
            className: "feature6-content",
            dots: false,
            wrapper: {
              className: "feature6-content-wrapper",
            },
            titleWrapper: {
              className: "feature6-title-wrapper",
              barWrapper: {
                className: "feature6-title-bar-wrapper",
                children: {
                  className: "feature6-title-bar",
                },
              },
              title: {
                className: "feature6-title",
              },
            },
            children: [
              {
                title: {
                  className: "feature6-title-text",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 417,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 418,
                            columnNumber: 15,
                          },
                        },
                        "Site Metrics",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 420,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    ),
                },
                className: "feature6-item",
                name: "block0",
                children: [
                  {
                    md: 8,
                    xs: 24,
                    className: "feature6-number-wrapper",
                    name: "child0",
                    number: {
                      className: "feature6-number",
                      unit: {
                        className: "feature6-unit",
                        children:
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 438,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 439,
                                  columnNumber: 21,
                                },
                              }
                            )
                          ),
                      },
                      toText: true,
                      children: "7500",
                    },
                    children: {
                      className: "feature6-text",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 449,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 450,
                                columnNumber: 19,
                              },
                            },
                            "New Users per Week",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 452,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                  },
                  {
                    md: 8,
                    xs: 24,
                    className: "feature6-number-wrapper",
                    name: "child1",
                    number: {
                      className: "feature6-number",
                      unit: {
                        className: "feature6-unit",
                        children:
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 468,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 469,
                                  columnNumber: 21,
                                },
                              }
                            )
                          ),
                      },
                      toText: true,
                      children: "47401426",
                    },
                    children: {
                      className: "feature6-text",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 479,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 480,
                                columnNumber: 19,
                              },
                            },
                            "Pageviews"
                          )
                        ),
                    },
                  },
                  {
                    md: 8,
                    xs: 24,
                    className: "feature6-number-wrapper",
                    name: "child2",
                    number: {
                      className: "feature6-number",
                      unit: {
                        className: "feature6-unit",
                        children:
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 495,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 496,
                                  columnNumber: 21,
                                },
                              }
                            )
                          ),
                      },
                      toText: true,
                      children: "87",
                    },
                    children: {
                      className: "feature6-text",
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 506,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 507,
                                columnNumber: 19,
                              },
                            },
                            "Different Countries",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 509,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                    },
                  },
                ],
              },
            ],
          },
        };
        const Content30DataSource = {
          wrapper: {
            className: "home-page-wrapper content3-wrapper",
          },
          page: {
            className: "home-page content3",
          },
          OverPack: {
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 530,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 531,
                          columnNumber: 13,
                        },
                      },
                      "Suggestions or Feedback",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 533,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content",
                className: "title-content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 543,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 544,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 545,
                            columnNumber: 15,
                          },
                        },
                        "We love feedback. Click on any of the buttons to get the conversation started",
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 548,
                              columnNumber: 17,
                            },
                          }
                        )
                      )
                    )
                  ),
              },
            ],
          },
          block: {
            className: "content3-block-wrapper",
            children: [
              {
                name: "block0",
                className: "content3-block",
                md: 8,
                xs: 24,
                children: {
                  icon: {
                    className: "content3-icon",
                    children:
                      "https://www.linespolice-cad.com/static/images/email-logo-512.png",
                  },
                  textWrapper: {
                    className: "content3-text",
                  },
                  title: {
                    className: "content3-title",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 574,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 575,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 576,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "a",
                              {
                                href: "mailto:support@linespolice-cad.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 577,
                                  columnNumber: 21,
                                },
                              },
                              "Email"
                            )
                          )
                        )
                      ),
                  },
                  content: {
                    className: "content3-content",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 592,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 593,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "br",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 594,
                                columnNumber: 19,
                              },
                            }
                          )
                        )
                      ),
                  },
                },
              },
              {
                name: "block1",
                className: "content3-block",
                md: 8,
                xs: 24,
                children: {
                  icon: {
                    className: "content3-icon",
                    children:
                      "https://www.linespolice-cad.com/static/images/report-bug-logo-512.png",
                  },
                  textWrapper: {
                    className: "content3-text",
                  },
                  title: {
                    className: "content3-title",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 616,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 617,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 618,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "a",
                              {
                                href: "https://github.com/Linesmerrill/police-cad/issues/new?assignees=&amp;labels=&amp;template=bug_report.md&amp;title=",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 619,
                                  columnNumber: 21,
                                },
                              },
                              "Report a Bug"
                            ),
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 626,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        )
                      ),
                  },
                  content: {
                    className: "content3-content",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 635,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 636,
                              columnNumber: 17,
                            },
                          }
                        )
                      ),
                  },
                },
              },
              {
                name: "block2",
                className: "content3-block",
                md: 8,
                xs: 24,
                children: {
                  icon: {
                    className: "content3-icon",
                    children:
                      "https://www.linespolice-cad.com/static/images/request-feature-logo-512.png",
                  },
                  textWrapper: {
                    className: "content3-text",
                  },
                  title: {
                    className: "content3-title",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 657,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 658,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "span",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 659,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "p",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 660,
                                  columnNumber: 21,
                                },
                              },
                              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                "a",
                                {
                                  href: "https://github.com/Linesmerrill/police-cad/issues/new?assignees=&labels=&template=feature_request.md&title=",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  __self: undefined,
                                  __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 661,
                                    columnNumber: 23,
                                  },
                                },
                                "Request a Feature"
                              ),
                              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                "br",
                                {
                                  __self: undefined,
                                  __source: {
                                    fileName: _jsxFileName,
                                    lineNumber: 668,
                                    columnNumber: 23,
                                  },
                                }
                              )
                            )
                          )
                        )
                      ),
                  },
                  content: {
                    className: "content3-content",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 678,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 679,
                              columnNumber: 17,
                            },
                          }
                        )
                      ),
                  },
                },
              },
              {
                name: "block3",
                className: "content3-block",
                md: 8,
                xs: 24,
                children: {
                  icon: {
                    className: "content3-icon",
                    children:
                      "https://www.linespolice-cad.com/static/images/discord-logo-512.png",
                  },
                  textWrapper: {
                    className: "content3-text",
                  },
                  title: {
                    className: "content3-title",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 700,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 701,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 702,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "a",
                              {
                                href: "https://discord.gg/3ECFhqe",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 703,
                                  columnNumber: 21,
                                },
                              },
                              "Discord"
                            )
                          )
                        )
                      ),
                  },
                  content: {
                    className: "content3-content",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 718,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 719,
                              columnNumber: 17,
                            },
                          }
                        )
                      ),
                  },
                },
              },
              {
                name: "block4",
                className: "content3-block",
                md: 8,
                xs: 24,
                children: {
                  icon: {
                    className: "content3-icon",
                    children:
                      "https://www.linespolice-cad.com/static/images/twitter-logo-512.png",
                  },
                  textWrapper: {
                    className: "content3-text",
                  },
                  title: {
                    className: "content3-title",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 740,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 741,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 742,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "a",
                              {
                                href: "https://twitter.com/LinesPoliceCAD",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 743,
                                  columnNumber: 21,
                                },
                              },
                              "Twitter"
                            )
                          )
                        )
                      ),
                  },
                  content: {
                    className: "content3-content",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 758,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 759,
                              columnNumber: 17,
                            },
                          }
                        )
                      ),
                  },
                },
              },
              {
                name: "block5",
                className: "content3-block",
                md: 8,
                xs: 24,
                children: {
                  icon: {
                    className: "content3-icon",
                    children:
                      "https://www.linespolice-cad.com/static/images/facebook-logo-512.png",
                  },
                  textWrapper: {
                    className: "content3-text",
                  },
                  title: {
                    className: "content3-title",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 780,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 781,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 782,
                                columnNumber: 19,
                              },
                            },
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "a",
                              {
                                href: "https://www.facebook.com/linespoliceserver/",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 783,
                                  columnNumber: 21,
                                },
                              },
                              "Facebook"
                            )
                          )
                        )
                      ),
                  },
                  content: {
                    className: "content3-content",
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 798,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "br",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 799,
                              columnNumber: 17,
                            },
                          }
                        )
                      ),
                  },
                },
              },
            ],
          },
        };

        /***/
      },

    /***/ "./src/Home/index.jsx":
      /*!****************************!*\
    !*** ./src/Home/index.jsx ***!
    \****************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/Home/Nav0.jsx");
        /* harmony import */ var _Banner0__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./Banner0 */ "./src/Home/Banner0.jsx");
        /* harmony import */ var _Content0__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./Content0 */ "./src/Home/Content0.jsx");
        /* harmony import */ var _Feature6__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(/*! ./Feature6 */ "./src/Home/Feature6.jsx");
        /* harmony import */ var _Content3__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(/*! ./Content3 */ "./src/Home/Content3.jsx");
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(/*! ./data.source */ "./src/Home/data.source.js");
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/Home/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_8___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_8__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Home/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_7__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 57,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Banner0__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Banner0_1",
                  key: "Banner0_1",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_7__[
                      "Banner01DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 63,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content0__WEBPACK_IMPORTED_MODULE_4__["default"],
                {
                  id: "Content0_0",
                  key: "Content0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_7__[
                      "Content00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 69,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Feature6__WEBPACK_IMPORTED_MODULE_5__["default"],
                {
                  id: "Feature6_0",
                  key: "Feature6_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_7__[
                      "Feature60DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 75,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content3__WEBPACK_IMPORTED_MODULE_6__["default"],
                {
                  id: "Content3_0",
                  key: "Content3_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_7__[
                      "Content30DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 81,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 89,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/Home/less/antMotionStyle.less":
      /*!*******************************************!*\
    !*** ./src/Home/less/antMotionStyle.less ***!
    \*******************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Home/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Home/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Home/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/Home/utils.js":
      /*!***************************!*\
    !*** ./src/Home/utils.js ***!
    \***************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/Login/Content5.jsx":
      /*!********************************!*\
    !*** ./src/Login/Content5.jsx ***!
    \********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(/*! ./utils */ "./src/Login/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Login/Content5.jsx";

        class Content5 extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .PureComponent {
          constructor() {
            super(...arguments);
            this.getChildrenToRender = (data) =>
              data.map((item) => {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      key: item.name,
                    },
                    item,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 11,
                        columnNumber: 9,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "a",
                    Object.assign({}, item.children.wrapper, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 12,
                        columnNumber: 11,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "span",
                      Object.assign({}, item.children.img, {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 13,
                          columnNumber: 13,
                        },
                      }),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                        "img",
                        {
                          src: item.children.img.children,
                          height: "100%",
                          alt: "img",
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 14,
                            columnNumber: 15,
                          },
                        }
                      )
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "p",
                      Object.assign({}, item.children.content, {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 16,
                          columnNumber: 13,
                        },
                      }),
                      item.children.content.children
                    )
                  )
                );
              });
          }
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            const childrenToRender = this.getChildrenToRender(
              dataSource.block.children
            );
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 32,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "div",
                  Object.assign(
                    {
                      key: "title",
                    },
                    dataSource.titleWrapper,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 33,
                        columnNumber: 11,
                      },
                    }
                  ),
                  dataSource.titleWrapper.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_7__["getChildrenToRender"]
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default.a,
                  Object.assign(
                    {
                      className: `content-template ${props.className}`,
                    },
                    dataSource.OverPack,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 36,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["TweenOneGroup"],
                    Object.assign(
                      {
                        component:
                          antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                        key: "ul",
                        enter: {
                          y: "+=30",
                          opacity: 0,
                          type: "from",
                          ease: "easeInOutQuad",
                        },
                        leave: {
                          y: "+=30",
                          opacity: 0,
                          ease: "easeInOutQuad",
                        },
                      },
                      dataSource.block,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 40,
                          columnNumber: 13,
                        },
                      }
                    ),
                    childrenToRender
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content5;

        /***/
      },

    /***/ "./src/Login/Nav0.jsx":
      /*!****************************!*\
    !*** ./src/Login/Nav0.jsx ***!
    \****************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/Login/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Login/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/Login/data.source.js":
      /*!**********************************!*\
    !*** ./src/Login/data.source.js ***!
    \**********************************/
      /*! exports provided: Nav00DataSource, Content50DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content50DataSource",
          function () {
            return Content50DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Login/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Content50DataSource = {
          wrapper: {
            className:
              "home-page-wrapper content5-wrapper ljab3gqifyl-editor_css",
          },
          page: {
            className: "home-page content5 lja74sp6nmt-editor_css",
          },
          OverPack: {
            playScale: 0.3,
            className: "",
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 124,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 125,
                          columnNumber: 13,
                        },
                      },
                      "Login"
                    )
                  ),
                className: "title-h1 lja75phz19k-editor_css",
              },
              {
                name: "content",
                className: "title-content lja75xnlm9s-editor_css",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 134,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 135,
                          columnNumber: 13,
                        },
                      },
                      "Welcome back to Lines Police CAD!",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 137,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
              },
              {
                name: "content~lja705c52d",
                className: "lja706c8vys-editor_css",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 151,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 152,
                          columnNumber: 13,
                        },
                      },
                      "Don't have an account?",
                      " ",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "b",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 154,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "/signup",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 155,
                              columnNumber: 17,
                            },
                          },
                          "Create one here"
                        )
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 157,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
              },
            ],
          },
          block: {
            className: "content5-img-wrapper lja7bd5uwgi-editor_css",
            gutter: 16,
            children: [
              {
                name: "block0",
                className: "block lja7c6wz7vt-editor_css",
                md: 6,
                xs: 24,
                children: {
                  wrapper: {
                    className: "content5-block-content lja76825yz-editor_css",
                    href: "/login-civ",
                  },
                  img: {
                    children:
                      "https://www.linespolice-cad.com/static/images/civilian-login-logo-512.png",
                    className: "lja7hr31iy-editor_css",
                  },
                  content: {
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 165,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "p",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 166,
                              columnNumber: 17,
                            },
                          },
                          "Login with Existing Account"
                        )
                      ),
                    className: "lja787k3ld7-editor_css",
                  },
                },
              },
              // {
              //   name: "block1",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja78c03dqk-editor_css",
              //       href: "/login-police",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/police-login-logo-512.png",
              //       className: "lja7iwizeuq-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 190,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 191,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Police"
              //           )
              //         ),
              //       className: "lja78krpxml-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block2",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja78sleycj-editor_css",
              //       href: "/login-dispatch",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/dispatch-login-logo-512.png",
              //       className: "lja7izocmgf-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 215,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 216,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Dispatch"
              //           )
              //         ),
              //       className: "lja78p49zx-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block3",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja790verco-editor_css",
              //       href: "/login-community",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/community-login-logo-512.png",
              //       className: "lja7j2ivdgq-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 240,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 241,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Community"
              //           )
              //         ),
              //       className: "lja78xkehr-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block4",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja799kmegi-editor_css",
              //       href: "/login-ems",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/fire-login-logo-512.png",
              //       className: "lja7j61e72-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 265,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 266,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Fire"
              //           )
              //         ),
              //       className: "lja79677l68-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block5",
              //   className: "block lja7fuhkkt-editor_css",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja79icitt-editor_css",
              //       href: "/login-ems",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/ems-login-logo-512.png",
              //       className: "lja7j8ssy7-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 290,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 291,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "EMS"
              //           )
              //         ),
              //       className: "lja79e9m1m8-editor_css",
              //     },
              //   },
              // },
            ],
          },
        };

        /***/
      },

    /***/ "./src/Login/index.jsx":
      /*!*****************************!*\
    !*** ./src/Login/index.jsx ***!
    \*****************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/Login/Nav0.jsx");
        /* harmony import */ var _Content5__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./Content5 */ "./src/Login/Content5.jsx");
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./data.source */ "./src/Login/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/Login/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Login/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 48,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content5__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Content5_0",
                  key: "Content5_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Content50DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 54,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/Login/less/antMotionStyle.less":
      /*!********************************************!*\
    !*** ./src/Login/less/antMotionStyle.less ***!
    \********************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Login/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Login/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Login/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/Login/utils.js":
      /*!****************************!*\
    !*** ./src/Login/utils.js ***!
    \****************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/PageNotFound/Banner1.jsx":
      /*!**************************************!*\
    !*** ./src/PageNotFound/Banner1.jsx ***!
    \**************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js"
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_banner_anim__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-banner-anim */ "./node_modules/rc-banner-anim/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(/*! ./utils */ "./src/PageNotFound/utils.js");
        /* harmony import */ var rc_banner_anim_assets_index_css__WEBPACK_IMPORTED_MODULE_8__ =
          __webpack_require__(
            /*! rc-banner-anim/assets/index.css */ "./node_modules/rc-banner-anim/assets/index.css"
          );
        /* harmony import */ var rc_banner_anim_assets_index_css__WEBPACK_IMPORTED_MODULE_8___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_banner_anim_assets_index_css__WEBPACK_IMPORTED_MODULE_8__
          );

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PageNotFound/Banner1.jsx";

        const { BgElement } =
          rc_banner_anim__WEBPACK_IMPORTED_MODULE_6__["Element"];
        class Banner extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            const childrenToRender = dataSource.BannerAnim.children.map(
              (item, i) => {
                const elem = item.BannerElement;
                const elemClassName = elem.className;
                delete elem.className;
                const { bg, textWrapper, title, content, button } = item;
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_banner_anim__WEBPACK_IMPORTED_MODULE_6__["Element"],
                  Object.assign(
                    {
                      key: i.toString(),
                    },
                    elem,
                    {
                      prefixCls: elemClassName,
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 23,
                        columnNumber: 9,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    BgElement,
                    Object.assign(
                      {
                        key: "bg",
                      },
                      bg,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 24,
                          columnNumber: 11,
                        },
                      }
                    )
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    rc_queue_anim__WEBPACK_IMPORTED_MODULE_4__["default"],
                    Object.assign(
                      {
                        type: ["bottom", "top"],
                        delay: 200,
                        key: "text",
                      },
                      textWrapper,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 25,
                          columnNumber: 11,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "div",
                      Object.assign(
                        {
                          key: "logo",
                        },
                        title,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 31,
                            columnNumber: 13,
                          },
                        }
                      ),
                      typeof title.children === "string" &&
                        title.children.match(
                          _utils__WEBPACK_IMPORTED_MODULE_7__["isImg"]
                        )
                        ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                            "img",
                            {
                              src: title.children,
                              width: "100%",
                              alt: "img",
                              __self: this,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 34,
                                columnNumber: 17,
                              },
                            }
                          )
                        : title.children
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "div",
                      Object.assign(
                        {
                          key: "content",
                        },
                        content,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 39,
                            columnNumber: 13,
                          },
                        }
                      ),
                      content.children
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                      Object.assign(
                        {
                          ghost: true,
                          key: "button",
                        },
                        button,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 42,
                            columnNumber: 13,
                          },
                        }
                      ),
                      button.children
                    )
                  )
                );
              }
            );
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 50,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["TweenOneGroup"],
                {
                  key: "bannerGroup",
                  enter: {
                    opacity: 0,
                    type: "from",
                  },
                  leave: {
                    opacity: 0,
                  },
                  component: "",
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 51,
                    columnNumber: 9,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "div",
                  {
                    className: "banner1-wrapper",
                    key: "wrapper",
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 57,
                      columnNumber: 11,
                    },
                  },
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    rc_banner_anim__WEBPACK_IMPORTED_MODULE_6__["default"],
                    Object.assign(
                      {
                        key: "BannerAnim",
                      },
                      dataSource.BannerAnim,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 58,
                          columnNumber: 13,
                        },
                      }
                    ),
                    childrenToRender
                  )
                )
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["default"],
                {
                  animation: {
                    y: "-=20",
                    yoyo: true,
                    repeat: -1,
                    duration: 1000,
                  },
                  className: "banner1-icon",
                  style: {
                    bottom: 40,
                  },
                  key: "icon",
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 63,
                    columnNumber: 9,
                  },
                },
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__[
                    "DownOutlined"
                  ],
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 74,
                      columnNumber: 11,
                    },
                  }
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Banner;

        /***/
      },

    /***/ "./src/PageNotFound/Nav0.jsx":
      /*!***********************************!*\
    !*** ./src/PageNotFound/Nav0.jsx ***!
    \***********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/PageNotFound/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PageNotFound/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/PageNotFound/data.source.js":
      /*!*****************************************!*\
    !*** ./src/PageNotFound/data.source.js ***!
    \*****************************************/
      /*! exports provided: Nav00DataSource, Banner10DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Banner10DataSource",
          function () {
            return Banner10DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PageNotFound/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Banner10DataSource = {
          wrapper: {
            className: "banner1",
          },
          BannerAnim: {
            children: [
              {
                name: "elem0",
                BannerElement: {
                  className: "banner-user-elem",
                },
                textWrapper: {
                  className: "banner1-text-wrapper",
                },
                bg: {
                  className: "bg bg0",
                },
                title: {
                  className: "banner1-title lj7ljmx7pgb-editor_css",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 124,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 125,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 126,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "div",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 127,
                                columnNumber: 19,
                              },
                            },
                            "SORRY",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 129,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        )
                      )
                    ),
                },
                content: {
                  className: "banner1-content lj7lrdoyht-editor_css",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 139,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 140,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 141,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 142,
                                columnNumber: 19,
                              },
                            },
                            "We couldn't find that page"
                          ),
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 143,
                                columnNumber: 19,
                              },
                            },
                            "Try going to ",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "a",
                              {
                                href: "/",
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 144,
                                  columnNumber: 34,
                                },
                              },
                              "Lines Police CAD's home page"
                            ),
                            ".",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 145,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        )
                      )
                    ),
                },
                button: {
                  className: "banner1-button",
                  children:
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 155,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 156,
                            columnNumber: 15,
                          },
                        },
                        "Back Home"
                      )
                    ),
                  href: "/",
                },
              },
            ],
          },
        };

        /***/
      },

    /***/ "./src/PageNotFound/index.jsx":
      /*!************************************!*\
    !*** ./src/PageNotFound/index.jsx ***!
    \************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/PageNotFound/Nav0.jsx");
        /* harmony import */ var _Banner1__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! ./Banner1 */ "./src/PageNotFound/Banner1.jsx"
          );
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./data.source */ "./src/PageNotFound/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/PageNotFound/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PageNotFound/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 48,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Banner1__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Banner1_0",
                  key: "Banner1_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Banner10DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 54,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/PageNotFound/less/antMotionStyle.less":
      /*!***************************************************!*\
    !*** ./src/PageNotFound/less/antMotionStyle.less ***!
    \***************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PageNotFound/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PageNotFound/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PageNotFound/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/PageNotFound/utils.js":
      /*!***********************************!*\
    !*** ./src/PageNotFound/utils.js ***!
    \***********************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/PrivacyPolicy/Content13.jsx":
      /*!*****************************************!*\
    !*** ./src/PrivacyPolicy/Content13.jsx ***!
    \*****************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./utils */ "./src/PrivacyPolicy/utils.js");
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PrivacyPolicy/Content13.jsx";

        class Content13 extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default.a,
              Object.assign({}, props, dataSource.OverPack, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 13,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__["default"],
                Object.assign(
                  {
                    type: "bottom",
                    leaveReverse: true,
                    key: "page",
                    delay: [0, 100],
                  },
                  dataSource.titleWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 14,
                      columnNumber: 9,
                    },
                  }
                ),
                dataSource.titleWrapper.children.map(
                  _utils__WEBPACK_IMPORTED_MODULE_3__["getChildrenToRender"]
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content13;

        /***/
      },

    /***/ "./src/PrivacyPolicy/Nav0.jsx":
      /*!************************************!*\
    !*** ./src/PrivacyPolicy/Nav0.jsx ***!
    \************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/PrivacyPolicy/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PrivacyPolicy/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/PrivacyPolicy/data.source.js":
      /*!******************************************!*\
    !*** ./src/PrivacyPolicy/data.source.js ***!
    \******************************************/
      /*! exports provided: Nav00DataSource, Content131DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content131DataSource",
          function () {
            return Content131DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PrivacyPolicy/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Content131DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj3aekvt5qb-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 129,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 130,
                          columnNumber: 13,
                        },
                      },
                      "Privacy Policy",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 131,
                            columnNumber: 29,
                          },
                        }
                      )
                    )
                  ),
                className: "title-h1",
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 140,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 141,
                          columnNumber: 13,
                        },
                      },
                      "Effective date: August 30, 2018"
                    )
                  ),
                className: "title-content",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 149,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 150,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 151,
                            columnNumber: 15,
                          },
                        },
                        'Lines Police CAD ("us", "we", or "our") operates the https://linespolice-cad.com/ website (the "Service").'
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 155,
                            columnNumber: 15,
                          },
                        },
                        "This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. This Privacy Policy for Lines Police CAD is powered by FreePrivacyPolicy.com."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 162,
                            columnNumber: 15,
                          },
                        },
                        "We use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from https://linespolice-cad.com/terms-and-conditions"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 170,
                            columnNumber: 15,
                          },
                        },
                        "Information Collection And Use"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 171,
                            columnNumber: 15,
                          },
                        },
                        "We collect several different types of information for various purposes to provide and improve our Service to you."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 175,
                            columnNumber: 15,
                          },
                        },
                        "Types of Data Collected"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 176,
                            columnNumber: 15,
                          },
                        },
                        "Personal Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 177,
                            columnNumber: 15,
                          },
                        },
                        'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you ("Personal Data"). Personally identifiable information may include, but is not limited to:'
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 183,
                            columnNumber: 15,
                          },
                        },
                        "Email address"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 184,
                            columnNumber: 15,
                          },
                        },
                        "Cookies and Usage Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 185,
                            columnNumber: 15,
                          },
                        },
                        "Usage Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 186,
                            columnNumber: 15,
                          },
                        },
                        'We may also collect information how the Service is accessed and used ("Usage Data"). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.'
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 195,
                            columnNumber: 15,
                          },
                        },
                        "Tracking & Cookies Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 196,
                            columnNumber: 15,
                          },
                        },
                        "We use cookies and similar tracking technologies to track the activity on our Service and hold certain information."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 200,
                            columnNumber: 15,
                          },
                        },
                        "Cookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 207,
                            columnNumber: 15,
                          },
                        },
                        "You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 213,
                            columnNumber: 15,
                          },
                        },
                        "Examples of Cookies we use:"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 214,
                            columnNumber: 15,
                          },
                        },
                        "Session Cookies. We use Session Cookies to operate our Service."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 217,
                            columnNumber: 15,
                          },
                        },
                        "Preference Cookies. We use Preference Cookies to remember your preferences and various settings."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 221,
                            columnNumber: 15,
                          },
                        },
                        "Security Cookies. We use Security Cookies for security purposes."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 224,
                            columnNumber: 15,
                          },
                        },
                        "Use of Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 225,
                            columnNumber: 15,
                          },
                        },
                        "Lines Police CAD uses the collected data for various purposes:"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 228,
                            columnNumber: 15,
                          },
                        },
                        "To provide and maintain the Service"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 229,
                            columnNumber: 15,
                          },
                        },
                        "To notify you about changes to our Service"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 230,
                            columnNumber: 15,
                          },
                        },
                        "To allow you to participate in interactive features of our Service when you choose to do so"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 234,
                            columnNumber: 15,
                          },
                        },
                        "To provide customer care and support"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 235,
                            columnNumber: 15,
                          },
                        },
                        "To provide analysis or valuable information so that we can improve the Service"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 239,
                            columnNumber: 15,
                          },
                        },
                        "To monitor the usage of the Service"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 240,
                            columnNumber: 15,
                          },
                        },
                        "To detect, prevent and address technical issues"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 241,
                            columnNumber: 15,
                          },
                        },
                        "Transfer Of Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 242,
                            columnNumber: 15,
                          },
                        },
                        "Your information, including Personal Data, may be transferred to \u2014 and maintained on \u2014 computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 249,
                            columnNumber: 15,
                          },
                        },
                        "If you are located outside United States and choose to provide information to us, please note that we transfer the data, including Personal Data, to United States and process it there."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 254,
                            columnNumber: 15,
                          },
                        },
                        "Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 258,
                            columnNumber: 15,
                          },
                        },
                        "Lines Police CAD will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 266,
                            columnNumber: 15,
                          },
                        },
                        "Disclosure Of Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 267,
                            columnNumber: 15,
                          },
                        },
                        "Legal Requirements"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 268,
                            columnNumber: 15,
                          },
                        },
                        "Lines Police CAD may disclose your Personal Data in the good faith belief that such action is necessary to:"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 272,
                            columnNumber: 15,
                          },
                        },
                        "To comply with a legal obligation"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 273,
                            columnNumber: 15,
                          },
                        },
                        "To protect and defend the rights or property of Lines Police CAD"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 276,
                            columnNumber: 15,
                          },
                        },
                        "To prevent or investigate possible wrongdoing in connection with the Service"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 280,
                            columnNumber: 15,
                          },
                        },
                        "To protect the personal safety of users of the Service or the public"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 284,
                            columnNumber: 15,
                          },
                        },
                        "To protect against legal liability"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 285,
                            columnNumber: 15,
                          },
                        },
                        "Security Of Data"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 286,
                            columnNumber: 15,
                          },
                        },
                        "The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 293,
                            columnNumber: 15,
                          },
                        },
                        "Service Providers"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 294,
                            columnNumber: 15,
                          },
                        },
                        'We may employ third party companies and individuals to facilitate our Service ("Service Providers"), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.'
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 300,
                            columnNumber: 15,
                          },
                        },
                        "These third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 305,
                            columnNumber: 15,
                          },
                        },
                        "Analytics"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 306,
                            columnNumber: 15,
                          },
                        },
                        "We may use third-party Service Providers to monitor and analyze the use of our Service."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 310,
                            columnNumber: 15,
                          },
                        },
                        "Google Analytics"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 311,
                            columnNumber: 15,
                          },
                        },
                        "Google Analytics is a web analytics service offered by Google that tracks and reports website traffic. Google uses the data collected to track and monitor the use of our Service. This data is shared with other Google services. Google may use the collected data to contextualize and personalize the ads of its own advertising network."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 319,
                            columnNumber: 15,
                          },
                        },
                        "You can opt-out of having made your activity on the Service available to Google Analytics by installing the Google Analytics opt-out browser add-on. The add-on prevents the Google Analytics JavaScript (ga.js, analytics.js, and dc.js) from sharing information with Google Analytics about visits activity."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 326,
                            columnNumber: 15,
                          },
                        },
                        "For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: https://policies.google.com/privacy?hl=en"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 331,
                            columnNumber: 15,
                          },
                        },
                        "Links To Other Sites"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 332,
                            columnNumber: 15,
                          },
                        },
                        "Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party's site. We strongly advise you to review the Privacy Policy of every site you visit."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 338,
                            columnNumber: 15,
                          },
                        },
                        "We have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 343,
                            columnNumber: 15,
                          },
                        },
                        "Children's Privacy"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 344,
                            columnNumber: 15,
                          },
                        },
                        'Our Service does not address anyone under the age of 18 ("Children").'
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 348,
                            columnNumber: 15,
                          },
                        },
                        "We do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 357,
                            columnNumber: 15,
                          },
                        },
                        "Changes To This Privacy Policy"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 358,
                            columnNumber: 15,
                          },
                        },
                        "We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 363,
                            columnNumber: 15,
                          },
                        },
                        'We will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the "effective date" at the top of this Privacy Policy.'
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 368,
                            columnNumber: 15,
                          },
                        },
                        "You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page."
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 373,
                            columnNumber: 15,
                          },
                        },
                        "Contact Us"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 374,
                            columnNumber: 15,
                          },
                        },
                        "If you have any questions about this Privacy Policy, please contact us:"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 378,
                            columnNumber: 15,
                          },
                        },
                        "By email: support@linespolice-cad.com"
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 379,
                            columnNumber: 15,
                          },
                        },
                        "By visiting this page on our website: https://linespolice-cad.com/about-us"
                      )
                    )
                  ),
                className: "title-content lj3ae1qhurf-editor_css",
              },
            ],
          },
        };

        /***/
      },

    /***/ "./src/PrivacyPolicy/index.jsx":
      /*!*************************************!*\
    !*** ./src/PrivacyPolicy/index.jsx ***!
    \*************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/PrivacyPolicy/Nav0.jsx");
        /* harmony import */ var _Content13__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! ./Content13 */ "./src/PrivacyPolicy/Content13.jsx"
          );
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./data.source */ "./src/PrivacyPolicy/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/PrivacyPolicy/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/PrivacyPolicy/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 49,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Content13_1",
                  key: "Content13_1",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Content131DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 55,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 63,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/PrivacyPolicy/less/antMotionStyle.less":
      /*!****************************************************!*\
    !*** ./src/PrivacyPolicy/less/antMotionStyle.less ***!
    \****************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PrivacyPolicy/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PrivacyPolicy/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/PrivacyPolicy/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/PrivacyPolicy/utils.js":
      /*!************************************!*\
    !*** ./src/PrivacyPolicy/utils.js ***!
    \************************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/Signup/Content5.jsx":
      /*!*********************************!*\
    !*** ./src/Signup/Content5.jsx ***!
    \*********************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_row_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/row/style */ "./node_modules/antd/es/row/style/index.js"
          );
        /* harmony import */ var antd_es_row__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/row */ "./node_modules/antd/es/row/index.js"
          );
        /* harmony import */ var antd_es_col_style__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! antd/es/col/style */ "./node_modules/antd/es/col/style/index.js"
          );
        /* harmony import */ var antd_es_col__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! antd/es/col */ "./node_modules/antd/es/col/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_4__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6__
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ =
          __webpack_require__(/*! ./utils */ "./src/Signup/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Signup/Content5.jsx";

        class Content5 extends react__WEBPACK_IMPORTED_MODULE_4___default.a
          .PureComponent {
          constructor() {
            super(...arguments);
            this.getChildrenToRender = (data) =>
              data.map((item) => {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  antd_es_col__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      key: item.name,
                    },
                    item,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 11,
                        columnNumber: 9,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    "a",
                    Object.assign({}, item.children.wrapper, {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 12,
                        columnNumber: 11,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "span",
                      Object.assign({}, item.children.img, {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 13,
                          columnNumber: 13,
                        },
                      }),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                        "img",
                        {
                          src: item.children.img.children,
                          height: "100%",
                          alt: "img",
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 14,
                            columnNumber: 15,
                          },
                        }
                      )
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                      "p",
                      Object.assign({}, item.children.content, {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 16,
                          columnNumber: 13,
                        },
                      }),
                      item.children.content.children
                    )
                  )
                );
              });
          }
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            const childrenToRender = this.getChildrenToRender(
              dataSource.block.children
            );
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              "div",
              Object.assign({}, props, dataSource.wrapper, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 32,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  "div",
                  Object.assign(
                    {
                      key: "title",
                    },
                    dataSource.titleWrapper,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 33,
                        columnNumber: 11,
                      },
                    }
                  ),
                  dataSource.titleWrapper.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_7__["getChildrenToRender"]
                  )
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                  rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_6___default.a,
                  Object.assign(
                    {
                      className: `content-template ${props.className}`,
                    },
                    dataSource.OverPack,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 36,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
                    rc_tween_one__WEBPACK_IMPORTED_MODULE_5__["TweenOneGroup"],
                    Object.assign(
                      {
                        component:
                          antd_es_row__WEBPACK_IMPORTED_MODULE_1__["default"],
                        key: "ul",
                        enter: {
                          y: "+=30",
                          opacity: 0,
                          type: "from",
                          ease: "easeInOutQuad",
                        },
                        leave: {
                          y: "+=30",
                          opacity: 0,
                          ease: "easeInOutQuad",
                        },
                      },
                      dataSource.block,
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 40,
                          columnNumber: 13,
                        },
                      }
                    ),
                    childrenToRender
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content5;

        /***/
      },

    /***/ "./src/Signup/Nav0.jsx":
      /*!*****************************!*\
    !*** ./src/Signup/Nav0.jsx ***!
    \*****************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(/*! ./utils */ "./src/Signup/utils.js");

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Signup/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/Signup/data.source.js":
      /*!***********************************!*\
    !*** ./src/Signup/data.source.js ***!
    \***********************************/
      /*! exports provided: Nav00DataSource, Content50DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content50DataSource",
          function () {
            return Content50DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Signup/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Content50DataSource = {
          wrapper: {
            className:
              "home-page-wrapper content5-wrapper ljab3gqifyl-editor_css",
          },
          page: {
            className: "home-page content5 lja74sp6nmt-editor_css",
          },
          OverPack: {
            playScale: 0.3,
            className: "",
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 124,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 125,
                          columnNumber: 13,
                        },
                      },
                      "Sign up"
                    )
                  ),
                className: "title-h1 lja75phz19k-editor_css",
              },
              {
                name: "content",
                className: "title-content lja75xnlm9s-editor_css",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 134,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 135,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 136,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "p",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 137,
                              columnNumber: 17,
                            },
                          },
                          "Create a free account to get started with Lines Police CAD.",
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "br",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 140,
                                columnNumber: 19,
                              },
                            }
                          )
                        )
                      )
                    )
                  ),
              },
              {
                name: "content~lja705c52d",
                className: "lja706c8vys-editor_css",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 151,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 152,
                          columnNumber: 13,
                        },
                      },
                      "Already have an account?",
                      " ",
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "b",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 154,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "a",
                          {
                            href: "/login",
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 155,
                              columnNumber: 17,
                            },
                          },
                          "Log in here"
                        )
                      ),
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "br",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 157,
                            columnNumber: 15,
                          },
                        }
                      )
                    )
                  ),
              },
            ],
          },
          block: {
            className: "content5-img-wrapper lja7bd5uwgi-editor_css",
            gutter: 16,
            children: [
              {
                name: "block0",
                className: "block lja7c6wz7vt-editor_css",
                md: 6,
                xs: 24,
                children: {
                  wrapper: {
                    className: "content5-block-content lja76825yz-editor_css",
                    href: "/signup-civ",
                  },
                  img: {
                    children:
                      "https://www.linespolice-cad.com/static/images/civilian-login-logo-512.png",
                    className: "lja7hr31iy-editor_css",
                  },
                  content: {
                    children:
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 185,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "p",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 186,
                              columnNumber: 17,
                            },
                          },
                          "Create a Free Account"
                        )
                      ),
                    className: "lja787k3ld7-editor_css",
                  },
                },
              },
              // {
              //   name: "block1",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja78c03dqk-editor_css",
              //       href: "/signup-police",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/police-login-logo-512.png",
              //       className: "lja7iwizeuq-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 210,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 211,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Police"
              //           )
              //         ),
              //       className: "lja78krpxml-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block2",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja78sleycj-editor_css",
              //       href: "/signup-dispatch",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/dispatch-login-logo-512.png",
              //       className: "lja7izocmgf-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 235,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 236,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Dispatch"
              //           )
              //         ),
              //       className: "lja78p49zx-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block3",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja790verco-editor_css",
              //       href: "/signup-community",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/community-login-logo-512.png",
              //       className: "lja7j2ivdgq-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 260,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 261,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Community"
              //           )
              //         ),
              //       className: "lja78xkehr-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block4",
              //   className: "block",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja799kmegi-editor_css",
              //       href: "/signup-ems",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/fire-login-logo-512.png",
              //       className: "lja7j61e72-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 285,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 286,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "Fire"
              //           )
              //         ),
              //       className: "lja79677l68-editor_css",
              //     },
              //   },
              // },
              // {
              //   name: "block5",
              //   className: "block lja7fuhkkt-editor_css",
              //   md: 6,
              //   xs: 24,
              //   children: {
              //     wrapper: {
              //       className: "content5-block-content lja79icitt-editor_css",
              //       href: "/signup-ems",
              //     },
              //     img: {
              //       children:
              //         "https://www.linespolice-cad.com/static/images/ems-login-logo-512.png",
              //       className: "lja7j8ssy7-editor_css",
              //     },
              //     content: {
              //       children:
              //         /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //           "span",
              //           {
              //             __self: undefined,
              //             __source: {
              //               fileName: _jsxFileName,
              //               lineNumber: 310,
              //               columnNumber: 15,
              //             },
              //           },
              //           /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              //             "p",
              //             {
              //               __self: undefined,
              //               __source: {
              //                 fileName: _jsxFileName,
              //                 lineNumber: 311,
              //                 columnNumber: 17,
              //               },
              //             },
              //             "EMS"
              //           )
              //         ),
              //       className: "lja79e9m1m8-editor_css",
              //     },
              //   },
              // },
            ],
          },
        };

        /***/
      },

    /***/ "./src/Signup/index.jsx":
      /*!******************************!*\
    !*** ./src/Signup/index.jsx ***!
    \******************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./Nav0 */ "./src/Signup/Nav0.jsx");
        /* harmony import */ var _Content5__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./Content5 */ "./src/Signup/Content5.jsx");
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./data.source */ "./src/Signup/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/Signup/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/Signup/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 48,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content5__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Content5_0",
                  key: "Content5_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Content50DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 54,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/Signup/less/antMotionStyle.less":
      /*!*********************************************!*\
    !*** ./src/Signup/less/antMotionStyle.less ***!
    \*********************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Signup/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Signup/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/Signup/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/Signup/utils.js":
      /*!*****************************!*\
    !*** ./src/Signup/utils.js ***!
    \*****************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/TermsAndConditions/Content13.jsx":
      /*!**********************************************!*\
    !*** ./src/TermsAndConditions/Content13.jsx ***!
    \**********************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! rc-scroll-anim/lib/ScrollOverPack */ "./node_modules/rc-scroll-anim/lib/ScrollOverPack.js"
          );
        /* harmony import */ var rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! rc-queue-anim */ "./node_modules/rc-queue-anim/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! ./utils */ "./src/TermsAndConditions/utils.js"
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/TermsAndConditions/Content13.jsx";

        class Content13 extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .PureComponent {
          render() {
            const { ...props } = this.props;
            const { dataSource } = props;
            delete props.dataSource;
            delete props.isMobile;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              rc_scroll_anim_lib_ScrollOverPack__WEBPACK_IMPORTED_MODULE_1___default.a,
              Object.assign({}, props, dataSource.OverPack, {
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 13,
                  columnNumber: 7,
                },
              }),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                rc_queue_anim__WEBPACK_IMPORTED_MODULE_2__["default"],
                Object.assign(
                  {
                    type: "bottom",
                    leaveReverse: true,
                    key: "page",
                    delay: [0, 100],
                  },
                  dataSource.titleWrapper,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 14,
                      columnNumber: 9,
                    },
                  }
                ),
                dataSource.titleWrapper.children.map(
                  _utils__WEBPACK_IMPORTED_MODULE_3__["getChildrenToRender"]
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Content13;

        /***/
      },

    /***/ "./src/TermsAndConditions/Nav0.jsx":
      /*!*****************************************!*\
    !*** ./src/TermsAndConditions/Nav0.jsx ***!
    \*****************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var antd_es_menu_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/menu/style */ "./node_modules/antd/es/menu/style/index.js"
          );
        /* harmony import */ var antd_es_menu__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/menu */ "./node_modules/antd/es/menu/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! rc-tween-one */ "./node_modules/rc-tween-one/es/index.js"
          );
        /* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./utils */ "./src/TermsAndConditions/utils.js"
          );

        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/TermsAndConditions/Nav0.jsx";

        const { Item, SubMenu } =
          antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"];
        class Header extends react__WEBPACK_IMPORTED_MODULE_2___default.a
          .Component {
          constructor(props) {
            super(props);
            this.phoneClick = () => {
              const phoneOpen = !this.state.phoneOpen;
              this.setState({
                phoneOpen,
              });
            };
            this.state = {
              phoneOpen: undefined,
            };
          }
          render() {
            const { dataSource, isMobile, ...props } = this.props;
            const { phoneOpen } = this.state;
            const navData = dataSource.Menu.children;
            const navChildren = navData.map((item) => {
              const { children: a, subItem, ...itemProps } = item;
              if (subItem) {
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  SubMenu,
                  Object.assign(
                    {
                      key: item.name,
                    },
                    itemProps,
                    {
                      title:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, a, {
                            className:
                              `header0-item-block ${a.className}`.trim(),
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 35,
                              columnNumber: 15,
                            },
                          }),
                          a.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        ),
                      popupClassName: "header0-item-child",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 31,
                        columnNumber: 11,
                      },
                    }
                  ),
                  subItem.map(($item, ii) => {
                    const { children: childItem } = $item;
                    const child = childItem.href
                      ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "a",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 47,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        )
                      : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                          "div",
                          Object.assign({}, childItem, {
                            __self: this,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 51,
                              columnNumber: 17,
                            },
                          }),
                          childItem.children.map(
                            _utils__WEBPACK_IMPORTED_MODULE_4__[
                              "getChildrenToRender"
                            ]
                          )
                        );
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      Item,
                      Object.assign(
                        {
                          key: $item.name || ii.toString(),
                        },
                        $item,
                        {
                          __self: this,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 56,
                            columnNumber: 17,
                          },
                        }
                      ),
                      child
                    );
                  })
                );
              }
              return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                Item,
                Object.assign(
                  {
                    key: item.name,
                  },
                  itemProps,
                  {
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 9,
                    },
                  }
                ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "a",
                  Object.assign({}, a, {
                    className: `header0-item-block ${a.className}`.trim(),
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 11,
                    },
                  }),
                  a.children.map(
                    _utils__WEBPACK_IMPORTED_MODULE_4__["getChildrenToRender"]
                  )
                )
              );
            });
            const moment = phoneOpen === undefined ? 300 : null;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
              rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
              Object.assign(
                {
                  component: "header",
                  animation: {
                    opacity: 0,
                    type: "from",
                  },
                },
                dataSource.wrapper,
                props,
                {
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                "div",
                Object.assign({}, dataSource.page, {
                  className: `${dataSource.page.className}${
                    phoneOpen ? " open" : ""
                  }`,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 9,
                  },
                }),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign(
                    {
                      animation: {
                        x: -30,
                        type: "from",
                        ease: "easeOutQuad",
                      },
                    },
                    dataSource.logo,
                    {
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 84,
                        columnNumber: 11,
                      },
                    }
                  ),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "img",
                    {
                      width: "100%",
                      src: dataSource.logo.children,
                      alt: "img",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 88,
                        columnNumber: 13,
                      },
                    }
                  )
                ),
                isMobile &&
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    "div",
                    Object.assign({}, dataSource.mobileMenu, {
                      onClick: () => {
                        this.phoneClick();
                      },
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 91,
                        columnNumber: 13,
                      },
                    }),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 97,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 98,
                          columnNumber: 15,
                        },
                      }
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                      "em",
                      {
                        __self: this,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 15,
                        },
                      }
                    )
                  ),
                /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  rc_tween_one__WEBPACK_IMPORTED_MODULE_3__["default"],
                  Object.assign({}, dataSource.Menu, {
                    animation: isMobile
                      ? {
                          height: 0,
                          duration: 300,
                          onComplete: (e) => {
                            if (this.state.phoneOpen) {
                              e.target.style.height = "auto";
                            }
                          },
                          ease: "easeInOutQuad",
                        }
                      : null,
                    moment: moment,
                    reverse: !!phoneOpen,
                    __self: this,
                    __source: {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 11,
                    },
                  }),
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                    antd_es_menu__WEBPACK_IMPORTED_MODULE_1__["default"],
                    {
                      mode: isMobile ? "inline" : "horizontal",
                      defaultSelectedKeys: ["sub0"],
                      theme: "dark",
                      __self: this,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 121,
                        columnNumber: 13,
                      },
                    },
                    navChildren
                  )
                )
              )
            );
          }
        }
        /* harmony default export */ __webpack_exports__["default"] = Header;

        /***/
      },

    /***/ "./src/TermsAndConditions/data.source.js":
      /*!***********************************************!*\
    !*** ./src/TermsAndConditions/data.source.js ***!
    \***********************************************/
      /*! exports provided: Nav00DataSource, Content130DataSource, Content133DataSource */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Nav00DataSource",
          function () {
            return Nav00DataSource;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content130DataSource",
          function () {
            return Content130DataSource;
          }
        );

        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "Content133DataSource",
          function () {
            return Content133DataSource;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/TermsAndConditions/data.source.js";

        const Nav00DataSource = {
          wrapper: {
            className: "header0 home-page-wrapper",
          },
          page: {
            className: "home-page",
          },
          logo: {
            className: "header0-logo lj33lqeb18b-editor_css",
            children:
              "https://www.linespolice-cad.com/static/images/lpc_logo_new_2023_landscape_transparent.png",
          },
          Menu: {
            className: "header0-menu",
            children: [
              {
                name: "item0",
                className: "header0-item",
                children: {
                  href: "/",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 21,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 22,
                                columnNumber: 19,
                              },
                            },
                            "Home"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
                subItem: null,
              },
              {
                name: "item2",
                className: "header0-item",
                children: {
                  href: "/about-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 39,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 40,
                                columnNumber: 19,
                              },
                            },
                            "About"
                          )
                        ),
                      name: "text",
                    },
                  ],
                },
              },
              {
                name: "item~lig6g12fgs",
                className: "header0-item",
                children: {
                  href: "/contact-us",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 56,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 57,
                                columnNumber: 19,
                              },
                            },
                            "Contact Us",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 59,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
              {
                name: "item~lj2yllcqn7",
                className: "header0-item",
                children: {
                  href: "https://www.linespolice-cad.com/discord-bot",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 77,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 78,
                                columnNumber: 19,
                              },
                            },
                            "Discord Bot",
                            /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                              "br",
                              {
                                __self: undefined,
                                __source: {
                                  fileName: _jsxFileName,
                                  lineNumber: 80,
                                  columnNumber: 21,
                                },
                              }
                            )
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "_blank",
                },
              },
              {
                name: "item~lj3c2crocd",
                className: "header0-item",
                children: {
                  href: "/login",
                  children: [
                    {
                      children:
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "span",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 98,
                              columnNumber: 17,
                            },
                          },
                          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "p",
                            {
                              __self: undefined,
                              __source: {
                                fileName: _jsxFileName,
                                lineNumber: 99,
                                columnNumber: 19,
                              },
                            },
                            "Login"
                          )
                        ),
                      name: "text",
                    },
                  ],
                  target: "",
                },
              },
            ],
          },
          mobileMenu: {
            className: "header0-mobile-menu",
          },
        };
        const Content130DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj33686irk-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 129,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "span",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 130,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "p",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 131,
                            columnNumber: 15,
                          },
                        },
                        "Terms and Conditions"
                      )
                    )
                  ),
                className: "title-h1",
              },
            ],
          },
        };

        const Content133DataSource = {
          OverPack: {
            className:
              "home-page-wrapper content13-wrapper lj39mclik0g-editor_css",
            playScale: 0.3,
          },
          titleWrapper: {
            className: "title-wrapper",
            children: [
              {
                name: "image",
                children:
                  "https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg",
                className: "title-image",
              },
              {
                name: "title~lj3a2xsv8im",
                className: "",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "p",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 237,
                        columnNumber: 13,
                      },
                    },
                    "Welcome to Lines Police CAD!"
                  ),
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 244,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "b",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 245,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 246,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "p",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 247,
                              columnNumber: 17,
                            },
                          },
                          "Last updated: April 26, 2025"
                        )
                      )
                    )
                  ),
                className: "title-content lj3a3dnbrpn-editor_css",
              },
              {
                name: "content2",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 244,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "b",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 245,
                          columnNumber: 13,
                        },
                      },
                      /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                        "span",
                        {
                          __self: undefined,
                          __source: {
                            fileName: _jsxFileName,
                            lineNumber: 246,
                            columnNumber: 15,
                          },
                        },
                        /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                          "p",
                          {
                            __self: undefined,
                            __source: {
                              fileName: _jsxFileName,
                              lineNumber: 247,
                              columnNumber: 17,
                            },
                          },
                          "These terms and conditions outline the rules and regulations for the use of Lines Police CAD's Website, located at https://linespolice-cad.com/."
                        )
                      )
                    )
                  ),
                className: "title-content lj3a3dnbrpn-editor_css",
              },
              {
                name: "content",
                children:
                  /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                    "span",
                    {
                      __self: undefined,
                      __source: {
                        fileName: _jsxFileName,
                        lineNumber: 261,
                        columnNumber: 11,
                      },
                    },
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 262,
                          columnNumber: 13,
                        },
                      },
                      "By accessing this website we assume you accept these terms and conditions. Do not continue to use Lines Police CAD if you do not agree to take all of the terms and conditions stated on this page. Our Terms and Conditions were created with the help of the Terms And Conditions Generator."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 269,
                          columnNumber: 13,
                        },
                      },
                      'The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: "Client", "You" and "Your" refers to you, the person log on this website and compliant to the Company\u2019s terms and conditions. "The Company", "Ourselves", "We", "Our" and "Us", refers to our Company. "Party", "Parties", or "Us", refers to both the Client and ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client\u2019s needs in respect of provision of the Company\u2019s stated services, in accordance with and subject to, prevailing law of Netherlands. Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they, are taken as interchangeable and therefore as referring to same.'
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 286,
                          columnNumber: 13,
                        },
                      },
                      "Cookies"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 287,
                          columnNumber: 13,
                        },
                      },
                      "We employ the use of cookies. By accessing Lines Police CAD, you agreed to use cookies in agreement with the Lines Police CAD's Privacy Policy."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 292,
                          columnNumber: 13,
                        },
                      },
                      "Most interactive websites use cookies to let us retrieve the user\u2019s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 299,
                          columnNumber: 13,
                        },
                      },
                      "License"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 300,
                          columnNumber: 13,
                        },
                      },
                      "Unless otherwise stated, Lines Police CAD and/or its licensors own the intellectual property rights for all material on Lines Police CAD. All intellectual property rights are reserved. You may access this from Lines Police CAD for your own personal use subjected to restrictions set in these terms and conditions."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 307,
                          columnNumber: 13,
                        },
                      },
                      "You must not:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 308,
                          columnNumber: 13,
                        },
                      },
                      " Republish material from Lines Police CAD"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 309,
                          columnNumber: 13,
                        },
                      },
                      " Sell, rent or sub-license material from Lines Police CAD"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 310,
                          columnNumber: 13,
                        },
                      },
                      " Reproduce, duplicate or copy material from Lines Police CAD"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 311,
                          columnNumber: 13,
                        },
                      },
                      " Redistribute content from Lines Police CAD"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 312,
                          columnNumber: 13,
                        },
                      },
                      "This Agreement shall begin on the date hereof."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 313,
                          columnNumber: 13,
                        },
                      },
                      "Parts of this website offer an opportunity for users to post and exchange opinions and information in certain areas of the website. Lines Police CAD does not filter, edit, publish or review Comments prior to their presence on the website. Comments do not reflect the views and opinions of Lines Police CAD, its agents and/or affiliates. Comments reflect the views and opinions of the person who post their views and opinions. To the extent permitted by applicable laws, Lines Police CAD shall not be liable for the Comments or for any liability, damages or expenses caused and/or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 326,
                          columnNumber: 13,
                        },
                      },
                      "Lines Police CAD reserves the right to monitor all Comments and to remove any Comments which can be considered inappropriate, offensive or causes breach of these Terms and Conditions."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 331,
                          columnNumber: 13,
                        },
                      },
                      "You warrant and represent that:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 332,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 337,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "The Comments do not invade any intellectual property right, including without limitation copyright, patent or trademark of any third party;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 343,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "The Comments do not contain any defamatory, libelous, offensive, indecent or otherwise unlawful material which is an invasion of privacy"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 349,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "The Comments will not be used to solicit or promote business or custom or present commercial activities or unlawful activity."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 354,
                          columnNumber: 13,
                        },
                      },
                      "You hereby grant Lines Police CAD a non-exclusive license to use, reproduce, edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats or media."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 359,
                          columnNumber: 13,
                        },
                      },
                      "Subscriptions"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Lines Police CAD offers subscription plans to enhance your experience on our platform. We provide two types of subscriptions: User Subscription Plans for individual users and Community Promotion Tiers for advertising communities. By subscribing to any plan, you agree to the following terms:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h3",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "User Subscription Plans"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "These plans enhance your personal experience on the platform:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Plans and Features:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Base Plan ($3/month or $2.67/month annually): Allows you to create up to 5 communities, access default departments, and experience the app with full ads."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Premium Plan ($8/month or $7.08/month annually): Includes a verified checkmark on your profile, the ability to create up to 10 communities, access to default departments, and a reduced ad experience with up to 50% fewer ads."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Premium + Plan ($19.99/month or $17.49/month annually): Provides a verified checkmark, unlimited community creation, custom departments, and an ad-free experience."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Billing and Payment:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "User Subscription Plans are available on a monthly or annual basis. Annual plans offer a discounted rate, saving you 12% compared to the monthly billing option."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "You will be charged the full amount for the selected billing period (monthly or annual) at the time of subscription."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Subscriptions auto-renew at the end of each billing period unless cancelled. You must cancel at least 24 hours prior to the next renewal to avoid additional charges."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Payments are processed securely through Stripe. You agree to provide accurate payment information and authorize Lines Police CAD to charge the applicable subscription fees."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Cancellation and Management:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      'You may cancel your User Subscription Plan at any time through the "Manage Subscription" section of the app. Upon cancellation, your subscription benefits will remain active until the end of the current billing period.'
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Terms may vary depending on the platform you subscribed on (e.g., iOS, Android, or web). You are responsible for managing your subscription directly with the platform provider if applicable."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "User Obligations:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "You agree not to share your User Subscription Plan benefits with other users or attempt to bypass subscription limits (e.g., creating additional accounts to exceed community creation limits)."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Lines Police CAD reserves the right to suspend or terminate your subscription if we detect misuse or violation of these terms."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h3",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Community Promotion Tiers"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "These tiers allow you to advertise your community on the platform:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Tiers and Features:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Basic Tier ($5/month): Includes promotional text in search results to help your community stand out."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Standard Tier ($10/month): Includes promotional text in search results and a verified community badge to build trust with potential members."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Premium Tier ($20/month): Includes promotional text in search results, a verified community badge, and a boost on the Discover Communities page for increased visibility."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Elite Tier ($50/month): Includes promotional text in search results (up to 200 characters), a verified community badge, a boost on the Discover Communities page, and a featured spot on the Home Page for maximum exposure."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Billing and Payment:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Community Promotion Tiers are available on a monthly basis only."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "You will be charged the full monthly amount at the time of subscription."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Community Promotion Tiers auto-renew at the end of each billing period unless cancelled. You must cancel at least 24 hours prior to the next renewal to avoid additional charges."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Payments are processed securely through Stripe. You agree to provide accurate payment information and authorize Lines Police CAD to charge the applicable subscription fees."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Cancellation and Management:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      'You may cancel your Community Promotion Tier at any time through the "Manage Subscription" section of the app. Upon cancellation, your promotion benefits will remain active until the end of the current billing period.'
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Terms may vary depending on the platform you subscribed on (e.g., iOS, Android, or web). You are responsible for managing your subscription directly with the platform provider if applicable."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h4",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "User Obligations:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Promotional text must comply with our content guidelines and must not contain inappropriate, offensive, or misleading information. Lines Police CAD reserves the right to reject or remove promotional text that violates these guidelines."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "The verified community badge and featured placements (e.g., on the Discover Communities page or Home Page) are subject to availability and may be adjusted at Lines Police CAD's discretion."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "You agree not to misuse promotion features, such as using multiple accounts to promote the same community beyond the allowed limits."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Lines Police CAD reserves the right to suspend or terminate your Community Promotion Tier if we detect misuse or violation of these terms."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h3",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Feature Descriptions:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 359,
                          columnNumber: 13,
                        },
                      },
                      "Lines Police CAD provides feature descriptions to help you understand the benefits of each subscription plan and community promotion tier. These descriptions are accessible via an information icon next to each feature in the subscription selection screen. By interacting with these icons, you acknowledge the following:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Feature descriptions are provided for informational purposes only and do not constitute a guarantee of specific functionality or performance."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Lines Police CAD reserves the right to modify or discontinue features at any time, with or without notice. Any such changes will be reflected in the subscription selection screen and updated feature descriptions."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "Accessing feature descriptions does not affect your subscription status or billing."
                    ),

                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 359,
                          columnNumber: 13,
                        },
                      },
                      "Hyperlinking to our Content"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 13,
                        },
                      },
                      "The following organizations may link to our Website without prior written approval:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 364,
                          columnNumber: 13,
                        },
                      },
                      " Government agencies;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 365,
                          columnNumber: 13,
                        },
                      },
                      " Search engines;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 366,
                          columnNumber: 13,
                        },
                      },
                      " News organizations;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 367,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "Online directory distributors may link to our Website in the same manner as they hyperlink to the Websites of other listed businesses; and"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 373,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "System wide Accredited Businesses except soliciting non-profit organizations, charity shopping malls, and charity fundraising groups which may not hyperlink to our Web site."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 379,
                          columnNumber: 13,
                        },
                      },
                      "These organizations may link to our home page, to publications or to other Website information so long as the link: (a) is not in any way deceptive; (b) does not falsely imply sponsorship, endorsement or approval of the linking party and its products and/or services; and (c) fits within the context of the linking party\u2019s site."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 387,
                          columnNumber: 13,
                        },
                      },
                      "We may consider and approve other link requests from the following types of organizations:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 391,
                          columnNumber: 13,
                        },
                      },
                      "Commonly-known consumer and/or business information sources;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 392,
                          columnNumber: 13,
                        },
                      },
                      "Dot.com community sites;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 393,
                          columnNumber: 13,
                        },
                      },
                      "Associations or other groups representing charities;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 394,
                          columnNumber: 13,
                        },
                      },
                      "Online directory distributors;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 395,
                          columnNumber: 13,
                        },
                      },
                      "Internet portals;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 396,
                          columnNumber: 13,
                        },
                      },
                      "Accounting, law and consulting firms; and"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 397,
                          columnNumber: 13,
                        },
                      },
                      "Educational institutions and trade associations."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 398,
                          columnNumber: 13,
                        },
                      },
                      "We will approve link requests from these organizations if we decide that: (a) the link would not make us look unfavorably to ourselves or to our accredited businesses; (b) the organization does not have any negative records with us; (c) the benefit to us from the visibility of the hyperlink compensates the absence of Lines Police CAD; and (d) the link is in the context of general resource information."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 407,
                          columnNumber: 13,
                        },
                      },
                      "These organizations may link to our home page so long as the link: (a) is not in any way deceptive; (b) does not falsely imply sponsorship, endorsement or approval of the linking party and its products or services; and (c) fits within the context of the linking party\u2019s site."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 414,
                          columnNumber: 13,
                        },
                      },
                      "If you are one of the organizations listed in paragraph 2 above and are interested in linking to our website, you must inform us by sending an e-mail to Lines Police CAD. Please include your name, your organization name, contact information as well as the URL of your site, a list of any URLs from which you intend to link to our Website, and a list of the URLs on our site to which you would like to link. Wait 2-3 weeks for a response."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 423,
                          columnNumber: 13,
                        },
                      },
                      "Approved organizations may hyperlink to our Website as follows:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 426,
                          columnNumber: 13,
                        },
                      },
                      "By use of our corporate name; or"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 427,
                          columnNumber: 13,
                        },
                      },
                      "By use of the uniform resource locator being linked to; or"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 428,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "By use of any other description of our Website being linked to that makes sense within the context and format of content on the linking party\u2019s site."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 434,
                          columnNumber: 13,
                        },
                      },
                      "No use of Lines Police CAD's logo or other artwork will be allowed for linking absent a trademark license agreement."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 438,
                          columnNumber: 13,
                        },
                      },
                      "iFrames"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 439,
                          columnNumber: 13,
                        },
                      },
                      "Without prior approval and written permission, you may not create frames around our Webpages that alter in any way the visual presentation or appearance of our Website."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 444,
                          columnNumber: 13,
                        },
                      },
                      "Content Liability"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 445,
                          columnNumber: 13,
                        },
                      },
                      "We shall not be hold responsible for any content that appears on your Website. You agree to protect and defend us against all claims that is rising on your Website. No link(s) should appear on any Website that may be interpreted as libelous, obscene or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third party rights."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 453,
                          columnNumber: 13,
                        },
                      },
                      "Your Privacy"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 454,
                          columnNumber: 13,
                        },
                      },
                      "Please read our Privacy Policy"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 455,
                          columnNumber: 13,
                        },
                      },
                      "Reservation of Rights"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 456,
                          columnNumber: 13,
                        },
                      },
                      "We reserve the right to request that you remove all links or any particular link to our Website. You approve to immediately remove all links to our Website upon request. We also reserve the right to amend these terms and conditions and it\u2019s linking policy at any time. By continuously linking to our Website, you agree to be bound to and follow these linking terms and conditions."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 464,
                          columnNumber: 13,
                        },
                      },
                      "Removal of links from our website"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 465,
                          columnNumber: 13,
                        },
                      },
                      "If you find any link on our Website that is offensive for any reason, you are free to contact and inform us any moment. We will consider requests to remove links but we are not obligated to or so or to respond to you directly."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 471,
                          columnNumber: 13,
                        },
                      },
                      "We do not ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we promise to ensure that the website remains available or that the material on the website is kept up to date."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "h2",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 477,
                          columnNumber: 13,
                        },
                      },
                      "Disclaimer"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 478,
                          columnNumber: 13,
                        },
                      },
                      "To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions relating to our website and the use of this website. Nothing in this disclaimer will:"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 483,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "Limit or exclude our or your liability for death or personal injury;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 488,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "Limit or exclude our or your liability for fraud or fraudulent misrepresentation;"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 493,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "Limit any of our or your liabilities in any way that is not permitted under applicable law; or"
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "li",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 498,
                          columnNumber: 13,
                        },
                      },
                      " ",
                      "Exclude any of our or your liabilities that may not be excluded under applicable law."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 503,
                          columnNumber: 13,
                        },
                      },
                      "The limitations and prohibitions of liability set in this Section and elsewhere in this disclaimer: (a) are subject to the preceding paragraph; and (b) govern all liabilities arising under the disclaimer, including liabilities arising in contract, in tort and for breach of statutory duty."
                    ),
                    /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                      "p",
                      {
                        __self: undefined,
                        __source: {
                          fileName: _jsxFileName,
                          lineNumber: 510,
                          columnNumber: 13,
                        },
                      },
                      "As long as the website and the information and services on the website are provided free of charge, we will not be liable for any loss or damage of any nature."
                    )
                  ),
                className: "title-content lj39nmh2z7j-editor_css",
              },
            ],
          },
        };

        /***/
      },

    /***/ "./src/TermsAndConditions/index.jsx":
      /*!******************************************!*\
    !*** ./src/TermsAndConditions/index.jsx ***!
    \******************************************/
      /*! exports provided: default */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "default",
          function () {
            return Home;
          }
        );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! enquire-js */ "./node_modules/enquire-js/main.js"
          );
        /* harmony import */ var enquire_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            enquire_js__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _Nav0__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(
            /*! ./Nav0 */ "./src/TermsAndConditions/Nav0.jsx"
          );
        /* harmony import */ var _Content13__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(
            /*! ./Content13 */ "./src/TermsAndConditions/Content13.jsx"
          );
        /* harmony import */ var _data_source__WEBPACK_IMPORTED_MODULE_4__ =
          __webpack_require__(
            /*! ./data.source */ "./src/TermsAndConditions/data.source.js"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__ =
          __webpack_require__(
            /*! ./less/antMotionStyle.less */ "./src/TermsAndConditions/less/antMotionStyle.less"
          );
        /* harmony import */ var _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5___default =
          /*#__PURE__*/ __webpack_require__.n(
            _less_antMotionStyle_less__WEBPACK_IMPORTED_MODULE_5__
          );
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/TermsAndConditions/index.jsx";
        /* eslint no-undef: 0 */
        /* eslint arrow-parens: 0 */

        let isMobile;
        Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
          (b) => {
            isMobile = b;
          }
        );
        const { location = {} } = typeof window !== "undefined" ? window : {};
        class Home extends react__WEBPACK_IMPORTED_MODULE_0___default.a
          .Component {
          constructor(props) {
            super(props);
            this.state = {
              isMobile,
              show: !location.port, // 如果不是 dva 2.0 请删除
            };
          }

          componentDidMount() {
            // 适配手机屏幕;
            Object(enquire_js__WEBPACK_IMPORTED_MODULE_1__["enquireScreen"])(
              (b) => {
                this.setState({
                  isMobile: !!b,
                });
              }
            );
            // dva 2.0 样式在组件渲染之后动态加载，导致滚动组件不生效；线上不影响；
            /* 如果不是 dva 2.0 请删除 start */
            if (location.port) {
              // 样式 build 时间在 200-300ms 之间;
              setTimeout(() => {
                this.setState({
                  show: true,
                });
              }, 500);
            }
            /* 如果不是 dva 2.0 请删除 end */
          }

          render() {
            const children = [
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Nav0__WEBPACK_IMPORTED_MODULE_2__["default"],
                {
                  id: "Nav0_0",
                  key: "Nav0_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Nav00DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 53,
                    columnNumber: 7,
                  },
                }
              ),
              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Content13_0",
                  key: "Content13_0",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Content130DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 59,
                    columnNumber: 7,
                  },
                }
              ),

              /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                _Content13__WEBPACK_IMPORTED_MODULE_3__["default"],
                {
                  id: "Content13_3",
                  key: "Content13_3",
                  dataSource:
                    _data_source__WEBPACK_IMPORTED_MODULE_4__[
                      "Content133DataSource"
                    ],
                  isMobile: this.state.isMobile,
                  __self: this,
                  __source: {
                    fileName: _jsxFileName,
                    lineNumber: 71,
                    columnNumber: 7,
                  },
                }
              ),
            ];
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
              "div",
              {
                className: "templates-wrapper",
                ref: (d) => {
                  this.dom = d;
                },
                __self: this,
                __source: {
                  fileName: _jsxFileName,
                  lineNumber: 79,
                  columnNumber: 7,
                },
              },
              this.state.show && children
            );
          }
        }

        /***/
      },

    /***/ "./src/TermsAndConditions/less/antMotionStyle.less":
      /*!*********************************************************!*\
    !*** ./src/TermsAndConditions/less/antMotionStyle.less ***!
    \*********************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/TermsAndConditions/less/antMotionStyle.less"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/TermsAndConditions/less/antMotionStyle.less",
            function () {
              var newContent = __webpack_require__(
                /*! !../../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-7-1!../../../node_modules/postcss-loader/src??postcss!../../../node_modules/resolve-url-loader??ref--6-oneOf-7-3!../../../node_modules/less-loader/dist/cjs.js??ref--6-oneOf-7-4!./antMotionStyle.less */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/less-loader/dist/cjs.js?!./src/TermsAndConditions/less/antMotionStyle.less"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/TermsAndConditions/utils.js":
      /*!*****************************************!*\
    !*** ./src/TermsAndConditions/utils.js ***!
    \*****************************************/
      /*! exports provided: isImg, getChildrenToRender */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "isImg",
          function () {
            return isImg;
          }
        );
        /* harmony export (binding) */ __webpack_require__.d(
          __webpack_exports__,
          "getChildrenToRender",
          function () {
            return getChildrenToRender;
          }
        );
        /* harmony import */ var antd_es_button_style__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! antd/es/button/style */ "./node_modules/antd/es/button/style/index.js"
          );
        /* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! antd/es/button */ "./node_modules/antd/es/button/index.js"
          );
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_2__
          );

        const isImg = /^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?/;
        const getChildrenToRender = (item, i) => {
          let tag = item.name.indexOf("title") === 0 ? "h1" : "div";
          tag = item.href ? "a" : tag;
          let children =
            typeof item.children === "string" && item.children.match(isImg)
              ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                  "img",
                  {
                    src: item.children,
                    alt: "img",
                  }
                )
              : item.children;
          if (
            item.name.indexOf("button") === 0 &&
            typeof item.children === "object"
          ) {
            children =
              react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
                antd_es_button__WEBPACK_IMPORTED_MODULE_1__["default"],
                {
                  ...item.children,
                }
              );
          }
          return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
            tag,
            {
              key: i.toString(),
              ...item,
            },
            children
          );
        };

        /***/
      },

    /***/ "./src/index.css":
      /*!***********************!*\
    !*** ./src/index.css ***!
    \***********************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        var content = __webpack_require__(
          /*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css"
        );

        if (typeof content === "string") content = [[module.i, content, ""]];

        var transform;
        var insertInto;

        var options = { hmr: true };

        options.transform = transform;
        options.insertInto = undefined;

        var update = __webpack_require__(
          /*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js"
        )(content, options);

        if (content.locals) module.exports = content.locals;

        if (true) {
          module.hot.accept(
            /*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css",
            function () {
              var newContent = __webpack_require__(
                /*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css"
              );

              if (typeof newContent === "string")
                newContent = [[module.i, newContent, ""]];

              var locals = (function (a, b) {
                var key,
                  idx = 0;

                for (key in a) {
                  if (!b || a[key] !== b[key]) return false;
                  idx++;
                }

                for (key in b) idx--;

                return idx === 0;
              })(content.locals, newContent.locals);

              if (!locals)
                throw new Error(
                  "Aborting CSS HMR due to changed css-modules locals."
                );

              update(newContent);
            }
          );

          module.hot.dispose(function () {
            update();
          });
        }

        /***/
      },

    /***/ "./src/index.js":
      /*!**********************!*\
    !*** ./src/index.js ***!
    \**********************/
      /*! no exports provided */
      /***/ function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! react */ "./node_modules/react/index.js");
        /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            react__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! react-dom */ "./node_modules/react-dom/index.js"
          );
        /* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            react_dom__WEBPACK_IMPORTED_MODULE_1__
          );
        /* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2__ =
          __webpack_require__(/*! ./index.css */ "./src/index.css");
        /* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2___default =
          /*#__PURE__*/ __webpack_require__.n(
            _index_css__WEBPACK_IMPORTED_MODULE_2__
          );
        /* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_3__ =
          __webpack_require__(/*! ./App */ "./src/App.js");
        var _jsxFileName =
          "/Users/merrill/workspace/police-cad-react/src/index.js";

        // import * as serviceWorker from "./serviceWorker";

        react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render(
          /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
            _App__WEBPACK_IMPORTED_MODULE_3__["default"],
            {
              __self: undefined,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 7,
                columnNumber: 17,
              },
            }
          ),
          document.getElementById("root")
        );

        // If you want your app to work offline and load faster, you can change
        // unregister() to register() below. Note this comes with some pitfalls.
        // Learn more about service workers: http://bit.ly/CRA-PWA
        // serviceWorker.unregister();

        /***/
      },

    /***/ 1:
      /*!**************************************************************************************************************!*\
    !*** multi (webpack)/hot/dev-server.js ./node_modules/react-dev-utils/webpackHotDevClient.js ./src/index.js ***!
    \**************************************************************************************************************/
      /*! no static exports found */
      /***/ function (module, exports, __webpack_require__) {
        __webpack_require__(
          /*! /Users/merrill/workspace/police-cad-react/node_modules/webpack/hot/dev-server.js */ "./node_modules/webpack/hot/dev-server.js"
        );
        __webpack_require__(
          /*! /Users/merrill/workspace/police-cad-react/node_modules/react-dev-utils/webpackHotDevClient.js */ "./node_modules/react-dev-utils/webpackHotDevClient.js"
        );
        module.exports = __webpack_require__(
          /*! /Users/merrill/workspace/police-cad-react/src/index.js */ "./src/index.js"
        );

        /***/
      },
  },
  [[1, "runtime-main", 0]],
]);
//# sourceMappingURL=main.chunk.js.map
